-- Fiyo CMS SQL Backup
-- Generation Time: Oct 11, 2014 pm31 13:32 pm 

DROP TABLE IF EXISTS `fiyo57_apps`;

--

CREATE TABLE `fiyo57_apps` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `folder` varchar(200) NOT NULL,
  `author` varchar(50) NOT NULL,
  `type` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

--

INSERT INTO `fiyo57_apps` (`id`,`name`,`folder`,`author`,`type`) VALUES ("1","Article","app_article","Fiyo CMS","0"),
("2","Comment","app_comment","Fiyo CMS","2"),
("3","User","app_user","Fiyo CMS","0"),
("4","Search","app_search","Fiyo CMS","2"),
("5","Contact","app_contact","Fiyo CMS","1"),
("6","Permalink","app_sef","Fiyo CMS","2"),
("7","Sitemap","app_sitemap","Fiyo CMS","2"),
("34","Gallery","app_gallery","Fiyo Developers","1");

--

DROP TABLE IF EXISTS `fiyo57_article`;

--

CREATE TABLE `fiyo57_article` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `category` int(5) NOT NULL,
  `article` text NOT NULL,
  `date` datetime NOT NULL,
  `author` varchar(250) NOT NULL,
  `author_id` int(5) NOT NULL,
  `description` text NOT NULL,
  `tags` text NOT NULL,
  `keyword` text NOT NULL,
  `featured` int(1) NOT NULL,
  `status` int(1) NOT NULL,
  `level` int(1) NOT NULL,
  `hits` int(10) NOT NULL,
  `parameter` text NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `editor` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=196 DEFAULT CHARSET=latin1;

--

INSERT INTO `fiyo57_article` (`id`,`title`,`category`,`article`,`date`,`author`,`author_id`,`description`,`tags`,`keyword`,`featured`,`status`,`level`,`hits`,`parameter`,`updated`,`editor`) VALUES ("1","Fiyo CMS Hadir pada Tahun 2012","1","<p>Welcome :)</p>\n","2012-01-04 14:54:58","First Ryan","1","gyi","","","1","1","99","763","show_comment=0;\nshow_author=2;\nshow_date=2;\nshow_category=2;\nshow_tags=2;\nshow_hits=2;\nshow_rate=2;\nrate_value=47;\nrate_counter=11;\npanel_top=0;\npanel_bottom=1;\neditor_level=3;\nshow_title=0;\n","2014-09-20 11:55:43","1"),
("4","Fitur Baru di V.1.2.0","1","<p>Meski sebenarnya belum rilis versi stabel, tetapi v.1.2.0 sudah bisa digunakan. Hanya saja butuh sedikit penyempurnaan. Apalagi versi ini hampir setengah codingnya berbeda dengan versi sebelumnya yang masih bersifat <em>jadul</em>.</p>\n\n<p>Berkat komentar dan masukan dari para ahlinya dan para sahabat ditambah para pengguna Fiyo yang antusias selalu memberikan kritik dan saran. Fiyo mengalami kemajuan dalam pengolahan data dan koding yang di kompres banyak dari versi sebelumnya.</p>\n\n<p>Installer yang hanya berjalan normal hanya di sebagian software localhost seperti di XAMPP dan WAMPP, tetapi tidak dapat mulus di Zend sudah sedikit diatasi di versi terbaru ini.</p>\n\n<hr id=\'system-readmore\' />\n<p>Berikut Fitur tambahan dan log di versi terbaru <strong>Fiyo v.1.2.0</strong></p>\n\n<h4>AddOns Intaller</h4>\n\n<p>Anda dapat memasang AddOns yang tersedia di situs resmi <strong>Fiyo.Org&nbsp;</strong>dan menginstalnya langsung di situs anda. AddOns adalah sebuah ekstensi tambahan yang ada di FiyoCMS seperti,<em> theme, module, plugin, apps.&nbsp;</em>Tetapi Anda harus sabar jika ingin mengambil AddOns di situs resminya, karena belum tersedia secara langsung dan masih dalam tahap penyempurnaan untuk situs Fiyo.Org itu sendiri.</p>\n\n<p>&nbsp;</p>\n\n<h4>Spot Position</h4>\n\n<p>Fitur ini memudahkan anda untuk mencari letak posisi modul pada theme anda, dengan hanya memilih gambar yang ada, dan tidak hanya tulisam saja. Fitur ini bisa anda temukan pada <strong>Module Manager</strong> dan <strong>Theme Manager.</strong></p>\n\n<p>&nbsp;</p>\n\n<p><strong>Work Logs Fiyo CMS</strong></p>\n\n<ol>\n	<li>pembenahan posisi modul pada modul manager belum akurat<em><span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span>1.1.0<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span>6-Jan-2012<span class=\'Apple-tab-span\' style=\'white-space: pre; \'> </span></em></li>\n	<li>merapikan tapilan tabel pada saat memilih &quot;single article&quot; di Menu Manager<span class=\'Apple-tab-span\' style=\'white-space: pre; \'> </span><em>1.1.0<span class=\'Apple-tab-span\' style=\'white-space: pre; \'> </span>6-Jan-2012</em></li>\n	<li>Penambahan menu AddOns Manager pada admin panel<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span><em>1.2.0<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span>7-Jan-2012</em></li>\n	<li>penambahan fitur AddOns Instaler<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span><em>1.2.0<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span>7-Jan-2012</em></li>\n	<li>penambahan fitur Apps AddOns<em><span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span>1.2.0<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span>8-Jan-2012</em></li>\n	<li>penambahan fitur Modules AddOns<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span><em>1.2.0<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span>8-Jan-2012</em></li>\n	<li>penambahan fitur Themes AddOns<em><span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span>1.2.0<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span>8-Jan-2012</em></li>\n</ol>\n\n<h4>Developer Logs Updated</h4>\n\n<ol>\n	<li>mark-up app_module untuk back-end<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span><em>6-Jan-2012</em></li>\n	<li>mark-up app_menu untuk back-end<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span><em>6-Jan-2012</em></li>\n	<li>penambahan fungsi extrak file zip -&gt; extractZip($file,$directory);<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span><em>8-Jan-2012</em></li>\n	<li>penambahan fungsi hapus direktori dan isinya -&gt; delete_directory($dirname);<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span><em>8-Jan-2012</em></li>\n</ol>\n\n<div>\n<h4>Issue</h4>\n\n<div>\n<ul>\n	<li>link kress (#) tidak berjalan&nbsp;<em><strong>solved</strong></em></li>\n	<li>posisi modul pada modul manager belum akurat&nbsp;<em><strong>solved</strong></em></li>\n	<li>Fiyo Installer tidak berjalan normal&nbsp;<em><strong>solved</strong></em></li>\n</ul>\n</div>\n</div>\n\n<p>&nbsp;</p>\n","2012-02-04 11:13:29","","1","","","","0","1","99","547","show_comment=2;\nshow_author=2;\nshow_date=2;\nshow_category=2;\nshow_tags=2;\nshow_hits=2;\nshow_rate=2;\nrate_value=19;\nrate_counter=3;\npanel_top=0;\npanel_bottom=0;\neditor_level=1;\n","2014-09-20 11:55:42","1"),
("6","Fiyo 1.2.2 dengan Fitur Lebih Canggih","1","<p><span style=\'line-height: 1.6em;\'>Rilis kali ini mempunyai perubahan yang signifikan dari rilis-update sebelumnya. Kali ini fitur yang ingin ditambahkan dari awal pembuatan FiyoCMS baru bisa dirasakan di versi 1.2.2 ini.</span></p><div style=\'page-break-after: always;\' contenteditable=\'false\' class=\'cke_pagebreak\' data-cke-display-name=\'pagebreak\' aria-label=\'Page Break\' title=\'Page Break\'></div><p>Yaitu fitur OneClickCange, dengan fitur ini mengatur artikel, menu dan modul terasa sangat mudah. Satu klik tanpa loading anda sudah bisa mengaktifkan atau menon-aktifkan artikel, modul atau menu yang anda inginkan.</p><p>Ditambah lagi di versi ini kita sudah bisa menyediakan module SlideShow, modul MultiFacebook, ImageScroll dan modul menarik lainya.</p><p>Pada versi ini juga ditambahkan Apps baru, yaitu App Contact. Anda bisa mengelola kontak para teman anda atau pegawai perusahaan.</p><p>Berikut Perubahan dan Fitur tambahan yang ada di Fiyo v 1.2.2</p><p><em><strong>Work Logs Fiyo CMS</strong></em></p><ul><li>penambahan plugins From Validator (JQuery)</li><li>penambahan plugins input limiter (JQuery)</li><li>fitur one click change pada Apps di AdminPanel&nbsp;&nbsp;(JQuery)</li><li>penyempurnaan plugin_sef</li><li>perbaikan : app_comment</li><li>perbaikan : app_article</li><li>penambahan : app_contact</li><li>perbaikan : app_user &nbsp;(Front Site)</li><li>perbaikan : app_module (Front Site)</li></ul><p><em><strong>Developer Logs Updates</strong></em></p><ul><li>Mengganti Field \'<strong>name</strong>\' dengan&nbsp;<strong>\'title</strong>\' pada tabel Article</li><li>penambahan fungsi&nbsp;<strong>get_htmlTag()</strong>&nbsp;sebagai fungsi tag parse</li></ul><p><br></p>","2012-02-19 13:00:29","","1","","","","1","1","99","463","show_comment=2;\nshow_author=2;\nshow_date=2;\nshow_category=1;\nshow_tags=2;\nshow_hits=2;\nshow_rate=2;\nrate_value=31;\nrate_counter=7;\npanel_top=0;\npanel_bottom=0;\neditor_level=2;\nshow_title=0;\n","2014-10-11 12:12:48","1"),
("7","Update checkpoint di versi 1.2.3","1","<p><span style=\'line-height: 1.6em;\'>Akhirnya setelah menunggu dan melakukan penambahan serta revisi dibagian system. Fiyo 1.2.3 dapat segera kami rilis. versi ini kami sebut dengan nama &nbsp;Fiyo one-two-three. Versi ini adalah yang terakhir untuk versi 1.2, yang berarti tidak akan ada lagi update untuk versi 1.2.x berikutnya.</span></p><p><span style=\'line-height: 1.6em;\'><img alt=\'\' data-cke-saved-src=\'/fiyo/media/images/login-blue.jpg\' src=\'/fiyo/media/images/login-blue.jpg\' style=\'width: 800px; height: 511px;\'></span></p><p>Walaupun masih ada beberapa fitur yang masih ingin ditambahkan seperti newsteller, dan fitur rating artikel. Tetapi ini diharap bisa menutup untuk versi 1.2 dan menjadikan Fiyo lebih dapat berkambang lebih canggih lagi.</p><div style=\'page-break-after: always;\' contenteditable=\'false\' class=\'cke_pagebreak\' data-cke-display-name=\'pagebreak\' aria-label=\'Page Break\' title=\'Page Break\'></div><p>Ok, berikut adalah fitur baru yang dimiliki Fiyo one-two-three.</p><h3>Add-Ons Manager Update</h3><p>Fitur Add-Ons Manager memang sudah lama ada, tetapi ada beberapa yang belum kami aktifkan. Tapi untuk saat ini anda bisa menggunakan semua fitur yang ada di Add-Ons Manager. Fitur baru seperti Plugins Manager atau penyempurnaan pada Add-Ons Installer bisa anda coba disini.</p><p>Update fitur ini adalah yang paling menonjol dan paling berpengaruh dalam update kali ini. Dengan sudah lengkapnya fitur pada Add-Ons Manager, diharapkan dapat mempermudah para developer khususnya untuk lebih mengembangkan Fiyo Add-Ons.</p><h3>Folder Admin Scure</h3><p>Anda pasti tahu jika FiyoCMS mendukung optimalisasi pengamanan folder admin. Dimana anda dapat mengganti nama folder admin sesuka anda. Tapi hal tersebut belum lengkap, karena masih harus dilakukan secara manual. Hal tersebut memang mudah dilakukan jika kita menjalankan FiyoCMS di server local (localhost), bagai mana jika di live server ? Pasti butuh proses yang panjang.</p><p>Kali ini anda dapat mengganti nama folder admin anda melalui menu Web Configuration pada menu Admin Panel. Lalu pilih bagian pojok kiri Konfigurasi Admin-Panel untuk mengganti nama folder admin dengan nama baru.</p><p><br></p>","2012-06-05 00:57:31","","0","","","","1","1","99","112","show_comment=1;\nshow_author=1;\nshow_date=1;\nshow_category=1;\nshow_tags=1;\nshow_hits=1;\nshow_rate=1;\nrate_value=27;\nrate_counter=3;\npanel_top=2;\npanel_bottom=2;\neditor_level=1;\nshow_title=2;\n","2014-10-11 12:11:09","5"),
("8","Membuat Template FiyoCMS","1","<p>Untuk memulai pembuatan tema perlu disiapkan file wajib dalam paket&nbsp;Fiyo Theme. File tersebut adalah sebagai berikut :</p>\n\n<ul>\n	<li>index.php</li>\n	<li>theme_details.php</li>\n	<li>theme_image.gif</li>\n	<li>spot_position.php (tambahan)</li>\n</ul>\n\n<h3>index.php</h3>\n\n<div style=\'page-break-after: always;\'><span style=\'display: none;\'>&nbsp;</span></div>\n\n<p><strong>index.php</strong> merupakan file utama untuk memuat seluruh file yang dibutuhkan. Untuk permulaan buat folder &#39;<strong>mytheme</strong>&#39; didalam folder root/themes/. Setelah itu buat file index.php dan sisipkan kode dibawah ini :</p>\n\n<pre class=\'brush:php\'>\n&lt;html&gt;\n    &lt;head&gt;&lt;title&gt;My Theme&lt;/title&gt;&lt;/head&gt;\n    &lt;body&gt;Text body&lt;/body&gt;\n&lt;/html&gt;</pre>\n\n<p>Setelah itu simpan dan set di Admin Panel untuk mengaktifkan mytheme sebagai tema utama. Apakah berhasil? Jika ya mungkin bisa kelangkah selanjutnya.</p>\n\n<p>Sekarang mulai untuk memuat system kedalam file tema. Sebelum itu kita perlu mengetahui fungsi dan konstanta yang bisa digunakan dalam membuat tema.</p>\n\n<ul>\n	<li><strong>FTitle </strong>: menampilkan judul situs sesuai format pada konfigurasi situs.</li>\n	<li><strong>FUrl </strong>: url utama atau url homepage.</li>\n	<li><strong>SiteName </strong>: nama situs.</li>\n	<li><strong>SiteTitle </strong>: judul situs.</li>\n	<li><strong>SiteLang </strong>: bahasa situs.</li>\n	<li><strong>MetaRobots </strong>: konfigurasi robots halaman.</li>\n	<li><strong>MetaDesc </strong>: deskripsi halaman.</li>\n	<li><strong>MetaKeys </strong>: katakunci halaman.</li>\n	<li><strong>FThemePath </strong>: direktori tema yang sedang digunakan.</li>\n	<li><strong>AdminPath </strong>: direktori tema AdminPanel.</li>\n	<li><strong>loadModule</strong>(&#39;posisi_modul&#39;) : memuat modul sesuai posisi dalam parameter.</li>\n	<li><strong>checkModule</strong>(&#39;posisi_modul&#39;) : digunakan apakah modul sesuai posisi parameter sedang aktif.</li>\n	<li><strong>loadApps</strong>() : memuat Apps.</li>\n	<li>\n	<div><strong><span style=\'line-height: 1.6em;\'>load</span></strong><span style=\'line-height: 1.6em;\'><strong>AppsCss</strong>() : fungsi untuk memuat seluruh css pada apps yang aktif.</span></div>\n	</li>\n	<li>\n	<div><strong><span style=\'line-height: 1.6em;\'>loadModuleCs</span></strong><span style=\'line-height: 1.6em;\'><strong>s</strong>() : fungsi untuk memuat seluruh module css yang aktif.</span></div>\n	</li>\n</ul>\n\n<p>Berikut adalah contoh potongan kode untuk bagian &lt;head&gt;.</p>\n\n<pre class=\'brush:php\'>\n&lt;!DOCTYPE html&gt;\n&lt;html lang=&quot;&lt;?php echo SiteLang; ?&gt;&quot;&gt;\n&lt;head&gt;\n    &lt;meta charset=&quot;utf-8&quot; /&gt;\n    &lt;title&gt;&lt;?php echo FTitle; ?&gt;&lt;/title&gt;\n    &lt;meta name=&quot;robots&quot; content=&quot;&lt;?php echo MetaRobots; ?&gt;&quot; /&gt;\n    &lt;meta name=&quot;keywords&quot; content=&quot;&lt;?php echo MetaKeys; ?&gt;&quot; /&gt;\n    &lt;meta name=&quot;description&quot; content=&quot;&lt;?php echo MetaDesc; ?&gt;&quot; /&gt;\n    &lt;meta name=&quot;generator&quot; content=&quot; Fiyo CMS Integrate Design Easily!&quot; /&gt;\n    &lt;?php loadAppsCss(); ?&gt;\n    &lt;?php loadModuleCss(); ?&gt;\n    &lt;link rel=&quot;shortcut icon&quot; type=&quot;image/x-icon&quot; href=&quot;&lt;?php echo FThemePath; ?&gt;/css/images/favicon.ico&quot; /&gt;\n    &lt;link rel=&quot;stylesheet&quot; href=&quot;&lt;?php echo FThemePath; ?&gt;/css/style.css&quot; type=&quot;text/css&quot; media=&quot;all&quot; /&gt;\n    &lt;script type=&quot;text/javascript&quot; src=&quot;&lt;?php echo FThemePath; ?&gt;/js/jquery-2.0.3.min.js&quot;&gt;&lt;/script&gt;\n&lt;/head&gt;</pre>\n\n<p>Pada potongan kode diatas hampir semua meta-tag sudah dipenuhi. fungsi loadCss(apps/modul) dimuat sebelum file css&nbsp;tema. Hal tersebut bertujuan agar css tema bisa mempengaruhi css modul/apps.&nbsp;</p>\n\n<p>Potongan kode diatas juga menunjukan bahwa terdapat folder css dan js yang menyimpan beberapa file pendukung. Disaranka untuk tidak memnuliskan javascript dalam mode inline atau langsung pada file index.php. Karena dapat merusak <em>module position</em>&nbsp;dari tema yang dibuat. pisahkan kedalam file tersendiri juga membuat struktur dan penulisan kode lebih rapi.</p>\n\n<p>Setelah bagian <em>head</em>&nbsp;selanjutnya bagian <em>body</em>. Perhatikan potongan kode berikut :</p>\n\n<pre class=\'brush:php\'>\n&lt;body&gt;\n   &lt;header id=&quot;header&quot;&gt;\n       &lt;div id=&quot;logo&quot;&gt;&lt;a href=&quot;&lt;?php echo FUrl; ?&gt;&quot;&gt;&lt;?php echo SiteName; ?&gt;&lt;/a&gt;\n       &lt;span&gt;&lt;?php echo SiteTitle; ?&gt;&lt;/span&gt;&lt;/div&gt;\n   &lt;/header&gt;\n   \n   &lt;nav id=&quot;navigation&quot;&gt;    \n      &lt;?php echo loadModule(&#39;mainmenu&#39;) ?&gt;\n   &lt;/nav&gt;\n   \n   &lt;div class=&quot;m-slider&quot;&gt;\n      &lt;?php loadModule(&#39;slide&#39;);?&gt;\n   &lt;/div&gt;        \n               \n   &lt;div class=&quot;main&quot;&gt;      \n&nbsp;      &lt;?php if(checkModule(&#39;right&#39;)) : ?&gt;  \n          &lt;div class=&quot;full&quot;&gt;\n&nbsp;            &lt;?php loadApps(); ?&gt;\n          &lt;/div&gt;\n&nbsp;      &lt;?php else : ?&gt;\n          &lt;div class=&#39;left&#39;&gt;\n&nbsp;            &lt;?php loadApps(); ?&gt;\n&nbsp;         &lt;/div&gt;\n&nbsp;         &lt;div class=&#39;right&#39;&gt;          \n             &lt;?php loadModule(&#39;right&#39;);?&gt;\n          &lt;/div&gt;\n&nbsp;      &lt;?php endif; ?&gt;\n   &lt;/div&gt;\n&lt;/body&gt;</pre>\n\n<p><span style=\'line-height: 1.6em;\'>Jika dilihat menurut potongan kode diatas terdapat posisi module mainmenu, slide dan right. Pada bagian konten akan tampil lebar jika module right tidak aktif. Dan akan dibagi menjadi dua bagian jika module right ada yang aktif sesuai kontrol checkModule().</span></p>\n\n<p>Setelah membuat file index.php secara lengkap sebenarnya sudah bisa digunakan secara utuh untuk Fiyo Theme. Namun, perlu theme_details.php sebagai informasi tema dan theme_image.gif sebagai gambar pendukung dari informasi tema.</p>\n\n<h3>theme_details.php</h3>\n\n<p>isi dan modifikasi bagian theme_details sesuai informasi tema yang diperlukan. Berikut contoh file theme_details.php.</p>\n\n<pre class=\'brush:php\'>\n$theme_name          =&#39;First Panel&#39;;\n$theme_version       =&#39;1.5.0&#39;;\n$theme_date          =&#39;17 August 2013&#39;;\n$theme_author        =&#39;Fiyo CMS&#39;;\n$theme_author_url    =&#39;http://portofolio.web.id&#39;;\n$theme_author_email  =&#39;firstryan@gmail.com&#39;;</pre>\n\n<h3>theme_image.gif</h3>\n\n<p>Buat screenshoot dari tema yang dibuat sebagai <em>thumbnail</em>&nbsp;(preview)&nbsp;tema. Rekomendasi berukuran 200x200 atau dengan ukuran yang presisi.</p>\n\n<h3>spot_position.php</h3>\n\n<p>Ini merupakan fitur dari Fiyo yaitu dapat memilih posisi modul dengan memilih dari preview tema. Pertama kita perlu menyiapkan terlebih dahulu gambar atau preview untuk&nbsp;spot_position. (misal spot_position.gif) Setelah itu gunakan dreamwaver untuk membuat imageMap sesuai modul yang dibuat.</p>\n\n<p>Hasil dari imageMap dari Dreamweaver contohnya seperti ini.</p>\n\n<pre class=\'brush:php\'>\n&lt;h3&gt;Fiyo Theme&lt;/h3&gt;\n&lt;img src=&quot;spot_position.gif&quot; width=&quot;600&quot; border=&quot;0&quot; usemap=&quot;#Map&quot; /&gt;\n&lt;map name=&quot;Map&quot; id=&quot;Map&quot;&gt;&lt;area  name=&quot;bottom-content&quot; shape=&quot;rect&quot; coords=&quot;66,80,379,171&quot; alt=&quot;slide&quot; /&gt;&lt;area  name=&quot;bottom-content&quot; shape=&quot;rect&quot; coords=&quot;279,183,379,229&quot; alt=&quot;top3&quot; /&gt;&lt;area  name=&quot;bottom-content&quot; shape=&quot;rect&quot; coords=&quot;173,183,270,230&quot; alt=&quot;top2&quot; /&gt;&lt;area  name=&quot;bottom-content&quot; shape=&quot;rect&quot; coords=&quot;68,183,164,229&quot; alt=&quot;top1&quot; /&gt;&lt;area  name=&quot;bottom-content&quot; shape=&quot;rect&quot; coords=&quot;66,447,380,480&quot; alt=&quot;bottom&quot; /&gt;\n  &lt;area shape=&quot;rect&quot; coords=&quot;65,485,532,501&quot; alt=&quot;breadchumb&quot; /&gt;\n  &lt;area shape=&quot;rect&quot; coords=&quot;392,78,536,468&quot; alt=&quot;right&quot; /&gt;\n  &lt;area shape=&quot;rect&quot; coords=&quot;391,9,532,29&quot; alt=&quot;search&quot; /&gt;\n  &lt;area shape=&quot;rect&quot; coords=&quot;67,43,537,67&quot; alt=&quot;mainmenu&quot;/&gt;\n&lt;/map&gt;</pre>\n\n<p>Setelah file utama dan file pendukung siap sekarang bisa terapkan tema yang sudah dibuat.</p>\n\n<h3>Membuat Paket Installer</h3>\n\n<p>Jika berniat untuk berbagi dari tema yang sudah dibuat anda perlu menyiapkan paket installer agar dapat diinstal melalui AddOns Installer.&nbsp;</p>\n\n<h3>installer.php</h3>\n\n<p>buat file installer.php satu folder dengan file index.php. Dan diingat bahwa file installer akan hilang otomatis jika paket Fiyo Theme berhasil diinstall. Berikut contoh file installer.php</p>\n\n<pre class=\'brush:php\'>\n$addons[&#39;name&#39;]   = &#39;My Theme&#39;;\n$addons[&#39;type&#39;]   = &#39;themes&#39;;\n$addons[&#39;folder&#39;] = &#39;mytheme&#39;;\n$addons[&#39;info&#39;]   = &#39;&lt;h1&gt;Ini tema buatan saya :)&lt;/h1&gt;&#39;;</pre>\n\n<p>Setelah file installer terbentuk pilih semua file yang ada pada folder tema yang dibuat lalu klik kanan dan pilih kompres sebagai zip.&nbsp;<span style=\'line-height: 1.6em;\'>Jadi sekarang selain terdapat file pendukung tema juga terdapat file .zip sebagai file installer yang telah dibuat.</span></p>\n","2012-01-03 11:37:11","","1","","","","1","1","99","252","show_comment=1;\nshow_author=1;\nshow_date=1;\nshow_category=1;\nshow_tags=1;\nshow_hits=1;\nshow_rate=1;\nrate_value=24;\nrate_counter=5;\npanel_top=2;\npanel_bottom=2;\neditor_level=3;\nshow_title=2;\n","2014-09-20 11:55:43","1"),
("10","Fiyo CMS 1.3.0","2","<p>Tanggal s 16 October 2012, Fiyo CMS versi 1.3.0 resmi di rilis dan pertama kalo di unggah pada situs www.sourceforge.net. Seperti apa yang telah di sampaikan sebelumnya pada artikel Pre-release Fiyo 1.3.0&nbsp;ada beberapa update yang tidak sedikit di tambahkan dalam versi ini. Disamping vitur yang telah di sampaikan pada Pre-release, ada beberapa fitur tambahan yang memang di tambahkan karena kebutuhan. Mau tau apa saja fitur lengkap yang ada di Fiyo CMS 1.3.0? Berikut data lengjap tetang apa saja yang ada pada Fiyo CMS 1.3.0.</p>\n\n<p>Pada versi anyar ini, developer mencoba untuk melengkapi fitur multi bahasa yang ada untuk AdminPanel, dan melengkapi beberapa <em>helper&nbsp;</em>agar memudahkan user dalam membuat website. Jadi apabila anda kesulitan, anda bias membuka<em> helper&nbsp;</em>yang tersedia pada setiap halaman AdminPanel.</p>\n\n<div style=\'page-break-after: always;\'><span style=\'display: none;\'>&nbsp;</span></div>\n\n<p>Ada fitur <em><strong>Auto Tagging</strong></em>, jadi kita bisa memberikan tag pada artikel dan akan otomatis erbentuk ketika kita menekan koma atau enter, sehingga diharapkan mampu mengurangi kesalahan pada penulisan tag artikel.</p>\n\n<p>Fitur yang <em><strong>Global Default Page</strong></em> juga merupakan fitur baru, disini kita dapat menentukan halaman default untuk semua halaman yang tidak mempunyai halaman tetap. Jadi, halaman yang tidak mempunyai Page_ID akan mempunyai halaman dengan&nbsp;<em><strong>Global Default Page.</strong></em></p>\n\n<p>Serta ada fitur&nbsp;RSS Feed yang bisa anda dapatkan pada kategori artikel atau tag artikel pada bagian bawah halaman dengan icon khusus. Untuk daftar update dengan tanda <strong>Ready!&nbsp;</strong>belum sepenuhnya di aktifkan, karena itu bermain dengan <em>.htaccess.&nbsp;</em>Disarankan untuk merubah&nbsp;<em>.htaccess</em> untuk live server saja dan bukan server lokal. Anda bisa mengaktifkanya dengan merubah isi dari&nbsp;<em>.htaccess.</em></p>\n\n<p>Berikut daftar update untuk Fiyo CMS 1.3.0 :</p>\n\n<ul>\n	<li>Auto Generate Meta Description</li>\n	<li>Auto Generate Meta Keyword</li>\n	<li>Auto Generate Meta Robots</li>\n	<li>Auto Generate Meta Author</li>\n	<li>Optimize Page Title</li>\n	<li>GZiP <strong>Ready!</strong></li>\n	<li>SpeedUp Caching Server &amp; Browser <strong>Ready!</strong></li>\n	<li>Copressed Static File <strong>Ready!</strong></li>\n	<li>Scurity libwww (Library World Wide Web) via .httaccess<strong> Ready!</strong></li>\n	<li>RSS Feed</li>\n	<li>Auto Tagging</li>\n	<li>Default Global Page</li>\n</ul>\n\n<p>Fix Bug :</p>\n\n<ul>\n	<li>Scurity Media Manager</li>\n	<li>Auto Change AdminPanel</li>\n	<li>Auto Installer in LocalServer</li>\n	<li>MultiDeletation on Admin Panel</li>\n</ul>\n\n<p>Change Log :</p>\n\n<ul>\n	<li>Add new<em> data</em> for table <strong><em>_setting :</em></strong>\n\n	<ul>\n		<li>lang =&gt; language</li>\n		<li>backend_folder =&gt; Auto change AdminPanel</li>\n		<li>follow_link = Meta Robots</li>\n		<li>site_mail = Official Site Mail</li>\n	</ul>\n	</li>\n	<li>Add new <em>column</em>&nbsp;for table&nbsp;<strong><em>_article_category :</em></strong>\n	<ul>\n		<li>keyword =&gt; Meta Keyword category</li>\n	</ul>\n	</li>\n	<li>Add new&nbsp;<em>column</em>&nbsp;for table&nbsp;<strong><em>_menu :</em></strong>\n	<ul>\n		<li>global =&gt; Global default Page</li>\n	</ul>\n	</li>\n</ul>\n","2013-01-09 14:20:50","","0","","","","1","1","99","486","show_comment=1;\nshow_author=1;\nshow_date=1;\nshow_category=1;\nshow_tags=1;\nshow_hits=1;\nshow_rate=1;\nrate_value=24;\nrate_counter=6;\npanel_top=0;\npanel_bottom=1;\neditor_level=3;\nshow_title=2;\n","2014-10-11 13:06:07","5"),
("12","Mengenal Lebih Dekat tentang Fiyo CMS","1","<p>Bagi yang masih penasaran dan bertanya-tanya apa itu Fiyo CMS? Buat apa sih Fiyo CMS? Atau, apalagi nih Fiyo CMS? Jangan jangan itu virus? Wah kagak minat ah!</p><p>Tenang, tenang sabar dulu, langsung saja nih silahkan dibaca untuk lebih jelasnya.</p><div style=\'page-break-after: always;\' contenteditable=\'false\' class=\'cke_pagebreak\' data-cke-display-name=\'pagebreak\' aria-label=\'Page Break\' title=\'Page Break\'></div><p>Fiyo CMS adalah sebuah Content Management System.</p><blockquote><p>Apalagi nih Content Management System ?</p></blockquote><p>Content Management System atau dalam bahasa Indonesia disebut Sistem Manajemen Konten (disingkat CMS), adalah software yang memungkinkan seseorang untuk menambahkan dan/atau memanipulasi (mengubah) isi dari suatu situs Web.<em style=\'&amp;quote;font-size:\'>&nbsp;(<a data-cke-saved-href=\'http://id.wikipedia.org/wiki/Sistem_manajemen_konten\' href=\'http://id.wikipedia.org/wiki/Sistem_manajemen_konten\'>http://id.wikipedia.org/wiki/Sistem_manajemen_konten</a>)</em></p><p>Contoh lain CMS seperti Joomla, Wrodpress, bahkan Blogspot juga CMS looh. Gimana sudah bisa mengertikan apa itu CMS?</p><blockquote><p>Jadi sama aja antara Fiyo dengan CMS yang lain ?</p></blockquote><p>Ehmm, kalo dibilang sama sih iya, kan jenisanya juga sama-sama CMS. Tetapi Fiyo CMS juga pasti ada bedanya, apalagi dengan CMS yang sudah memiliki banyak developer (pengembang) seperti Joomla, Wrodpress, Drupal, dll.</p><p>Tapi tenang saja, Fiyo CMS mempunyai fitur yang gak kalah canggihnya. dari mulai kemudahan membuat sebuah theme atau convert template gratisan ke Fiyo Theme dengan cara yang mudah.</p><p>Ditambah lagi, developernya orang Indonesia yang ramah-ramah, jadi bisa mudah tanya jawab dengan mereka.</p><blockquote><p>Fiyo CMS free kan ?</p></blockquote><p>Oh, tentunya <em>free</em>! Karena disesuaikan dengan selera orang Indonesia, hahaha.</p><p>Fiyo CMS juga boleh di <em>otak-atik&nbsp;</em>sesuai kebutuhan, tetapi jangan merubah nama Fiyo CMS dengan nama baru lho! Sangat dilarang dan tidak bijak. Alangkah baiknya jika kita saling menghargai karya orang lain.</p><p>Yang terpenting adalah, kata free yang bararti bebas dan gratjs itu berbeda. Fiyo CMS adalah software free dalam arti <u>bebas</u>.</p><blockquote><p>Lisensinya gimana untuk Fiyo CMS ?</p></blockquote><p>Fiyo CMS menggunakan License&nbsp;GNU General Public License, version 3 (GPL-3.0) sebagai basis lisensinya.</p><p>Jadi menurut keterangan untuk lisensi tersebut, adalah setiap orang dapat mengopy (mengunduh) dan mendisitribusikan kembali. Tetapi tidak diperbolehkan untuk melakukan perubahan terhadap sistem yang ada tanpa izin.</p><blockquote><p>Emang Fiyo CMS bisa dipake buat apa aja sih ?</p></blockquote><p>Fiyo CMS sengaja disiapkan untuk pengembangan yang lebih lanjut, meski dasarnya adalah CMS yang simple. Dari kategori yang umum digunakan oleh orang-orang, yaitu digunakan untuk <em>ngeblog</em>, buat toko online, website perkantoran, &nbsp;website pemerintahan, dan masih banyak lagi sesuai keinginan anda.</p><p>Fiyo CMS yang berbasis Fiyo Framework juga telah dikembangkan untuk pembuatan sistem informasi berbasis website, seperti Sistem Administrasi Sekolah, Sistem Perkantoran, Sistem Keuangan, dan Sistem Database lainya.</p><p>Jadi, meski simple pengembangan Fiyo CMS masihlah panjang karena akan ada banyak penambahan AddOns seiring berjalanya waktu.&nbsp;</p><blockquote><p>Wah jadi gak sabar pingin coba nih :)</p></blockquote><p>Waaaah, udah pingin nyobai nih? Langsung aja download Fiyo CMS versi terbaru.</p><p>Sekian dulu ya artikel kali ini, semoga dapat menambah wawasan para pembaca.</p><p><em>Dukung terus buatab Asli 100% Indonesia !</em></p>","2012-05-01 22:35:31","","1","","","","1","1","99","1145","show_comment=1;\nshow_author=1;\nshow_date=1;\nshow_category=1;\nshow_tags=1;\nshow_hits=1;\nshow_rate=1;\nrate_value=34;\nrate_counter=7;\npanel_top=2;\npanel_bottom=1;\neditor_level=1;\nshow_title=2;\n","2014-10-11 12:43:54","1"),
("14","Fiyo CMS 1.5.0","1","<p>Semakin optimal peforma dari Fiyo CMS di versi 1.5.0 ini. Banyak perubahan dari sisi <em>system core</em> yang ada untuk mengoptimalkan Fiyo CMS. Kami ingin selalu menyajikan sebuah perangkat yang mudah digunakan, sangat mudah dan ringan diakses. Oleh karena itu kami akan terus melekukan perbaikan dan invoasi serta menerima saran dari para pengguna Fiyo CMS.</p>\n\n<p>Merupakan penyempurnaan dari versi sebelumnya, yaitu Fiyo 1.4.0 dengan penambahan fitur yang banyak, Fiyo 1.5.0 lebih spesifik kepada penyempurnaan dari awal Fiyo CMS terbentuh hingga versi yang sekarang. Fungsi dari AdminPanel dan situs depan telah aktif secara keseluruhan.</p>\n\n<hr id=\'system-readmore\' />\n<h2>Edit Theme</h2>\n\n<p>Fiyo 1.5.0 memiliki fitur baru dibagian <strong>Theme Manager</strong>, yaitu penambahan tombol <u>Edit Theme</u>. Dimana kita bisa mengedit file yang ada dalam <em>theme</em> yang dipilih.</p>\n\n<p style=\'text-align: center;\'><img alt=\'Edit Theme\' src=\'/media/images/edit_theme.jpg\' style=\'width: 464px; height: 298px;\' /></p>\n\n<p>Anda hanya perlu memilih file yang ingin di edit dan simpan dengan dengan mudah disisi kanan layar.</p>\n\n<p style=\'text-align: center;\'><img alt=\'Edit File Theme on Fiyo CMS\' src=\'/media/images/file_theme.gif\' style=\'width: 600px; height: 323px;\' /></p>\n\n<p>Dengan ini kita dengan mudah menambahkan tag custom apapun, seperti Google Analytics, file css, file javascript atau tag lainya.&nbsp;</p>\n\n<h2>HTML Valid Ready!</h2>\n\n<p>Memang semua bisa mengatakan bahwa mereka juga siap untuk menjadikan situs lulus uji validasi HTML. <u>Tetapi kami jauh lebih siap</u>&nbsp;Fiyo 1.5.0 akan membantu Anda untuk memuat semua file css didalam tag &lt;head&gt;. tinggal tambahkan kode berikut di setiap file tema yang digunakan,</p>\n\n<div><span style=\'font-family:courier new,courier,monospace;\'>&lt;?php loadAppsCss(); ?&gt;</span></div>\n\n<div><span style=\'font-family:courier new,courier,monospace;\'>&lt;?php loadModuleCss(); ?&gt;</span></div>\n\n<div>&nbsp;</div>\n\n<h2 style=\'text-align: center;\'><em>Fiyo 1.5.0, More Stable, More Fast and More Elegant</em></h2>\n","2013-08-01 21:26:08","","0","","","","1","1","99","674","show_comment=2;\nshow_author=2;\nshow_date=2;\nshow_category=2;\nshow_tags=2;\nshow_hits=2;\nshow_rate=2;\nrate_value=10;\nrate_counter=2;\npanel_top=2;\npanel_bottom=2;\neditor_level=3;\nshow_title=2;\n","2014-10-11 13:06:24","5"),
("195","Program Studi ABC DEFG ini adalah asdas dasd asd asdas das asd asd asd asd as","1","<p>jjj</p>\n","2014-10-02 13:51:31","","0","","","","1","1","99","9","show_comment=2;\nshow_author=2;\nshow_date=2;\nshow_category=2;\nshow_tags=2;\nshow_hits=2;\nshow_rate=2;\nrate_value=0;\nrate_counter=0;\npanel_top=2;\npanel_bottom=2;\neditor_level=3;\nshow_title=2;\n","2014-10-11 13:04:01","5"),
("175","Fiyo CMS 1.4.0","1","<p>Setelah melalui masa percobaan untuk berbagai situs yang telah kembangkan, maka Fiyo 1.4.0 resmi dirilis pa;da tanggal 4 April 2013. Dengan mengusung judul <strong>Fiyo Go Store!&nbsp;</strong>dan pastinya Fi Store pun menjadi senjata andalan.6</p>\n\n<p>Fersi baru ini memiliki perbedaan dan perkembangan yang cukup signifikan. Karena update kali ini tidak hanya memperbaiki tetapi juga menambah beberapa modul dan apps baru, serta memodifikasi dasboard AdminPanel agar lebih informatif.</p>\n\n<div style=\'page-break-after: always;\'><span style=\'display: none;\'>&nbsp;</span></div>\n\n<p>Kita akan bahas satu-persatu mulai dari (belakang (AdminPanel)&nbsp;hingga sisi depan (Front Site).</p>\n\n<h3>Dasboard AdminPanel</h3>\n\n<p>Pada saat pertama kali login pada AdminPanel pasti akan diarahkan ke halaman Dasboard. Kali ini dasboard akan sedikit dirubah layoutnya dan penambahan fitur statistik agar AdminPanel lebih informatif.</p>\n\n<p>Berikut preview tampilan dasboard AdminPanel.</p>\n\n<p><img alt=\'Dasboard Fiyo CMS\' longdesc=\'Dasboard Fiyo CMS\' src=\'/media/images/dasboard.jpg\' style=\'width: 630px; height: 368px;\' /></p>\n\n<p>Gambar diatas pada sisi kiri menujukan statistik artikel terbaru dari semenjak Anda login terakhir kali di AdminPanel, komentar yang belum disetujui, jumlah user baru, dan versi Fiyo yang digunakan.</p>\n\n<p>Serta pada sisi kiri ada <em>line-chart</em>&nbsp;yang menunjukan jumlah pengunjung perhari dalam 7 hari terakhir. data pada warna biru menunjukan pengunjung unik untuk setiap <em>session</em>-nya dan untuk warna merah adalah pengujung unik setiap IP yang berbeda.</p>\n\n<p>Juga perombakan <em>shortcut icon</em> agar lebih fokus dikiri dan lebih rapih.</p>\n\n<h3>Fiyo Installer</h3>\n\n<p>Pada Fiyo 1.4.0 untuk installernya dibaerikan popup informasi tambahan sebagai panduan instalasi.</p>\n\n<p>Apakah itu server lokal yang tidak harus membuat database atau user terlebih daulu. Ataukan di server hosting yang mengharuskan untuk membuat user atau database terlebih dahulu.</p>\n\n<h3>Article System</h3>\n\n<p>Ada fitur baru yang mungkin wajib diketahui di bagian artikel. Pada bagian editor terdapat tombol baru di samping tombol &#39;Read More&#39;, yaitu tombol &#39;Attach File&#39; yang berguna untuk memanggil file yang disimpan di Media Manager. Tombol ini biasa digunakan untuk menautkan file yang siap diunduh oleh pengujung situs.</p>\n\n<p>Juga adanya pengaturan penanggalan yang berfungsi untuk mengatur penjadwalan artikel. Jadi, apabila artikel belum memasuki tanggal yang telah ditetapkan, maka artikel belom muncul atau bisa dikatakan belum aktif. Hal ini juga akan merubah input tanggal menjadi (Y-M-d H:i:s).</p>\n\n<p>Dan pengembangan baru untuk artikel adalah, penataan layout. Anda bisa memilih model layout melalui Menu, lalu seting parameter sesuai keinginan. Berikut gambaran layout urut mulai dari default, blog dan list.</p>\n\n<p>&nbsp;</p>\n\n<h3>User Management</h3>\n\n<p>Pada bagiang User Managemement juga ditambahkan fungsi baru untuk mengatur apakah situs menerima pendaftaran baru dari pengunjung atau tidak.&nbsp;</p>\n\n<p>Anda bisa menemukan tombol setting pada bagian atas di samping tombol simpan, hapus dan bantuan.</p>\n\n<h3>Comment System</h3>\n\n<p>Sistem komentar yang menggunakan Fi Comment juga turut diperbaharui. Anda bisa menggunakan dua pilihan <em>security code</em>&nbsp;atau yang lebih dikenal dengan <strong>captcha</strong>.&nbsp;</p>\n\n<p>Pada bagian konfigurasi komentar terdapat dua kolom untuk menampilkan reCaptcha. Apabila kolom tersebut salah atau tidak diisi maka Fi Comment akan menggunakan captcha matematika.</p>\n\n<p>Capthca matematika sendiri juga sudah diperbaharui, tidak lagi bersifat teks dan sekarang berbantuk gambar. Alasan memilih captcha matematika adalah untuk mengasah otak agar lebih aktif lagi dengan hitungan-hitungan sederhana.</p>\n\n<h3>Statistic System</h3>\n\n<p>Ada plugin baru yang ditanamkan didalam Fiyo 1.4.0 ini, yaitu sistem statistik untuk melihat detil pengujung. Sistem ini bekerja apabila ada yang mengakses website dan langsung akan tercatat IP, waktu, user id, platform, browser, negara dan kota yang tersimpan ditabel<em> _statistic</em></p>\n\n<p>Tabel tersebut bisa dimanfaatkan untuk membuat sebuah AddOn baru. Contoh AddOn dari pengembangan tabel tersebut adalah, statistik pengunjung di AdminPanel dan modul Ststistik yang menggantikan <em>Fi Tracker</em>.</p>\n\n<h3>Fiyo Store</h3>\n\n<p>Kali ini AddOn yang banyak ditunggu-tunggu adalah Fiyo Store atau dikenal dengan <strong>Fi Store</strong>. Tetapi Fi Store tidak disertakan secara langsung dalam paket instalasi versi terbaru ini. Anda harus megunduhnya dihalaman AddOns.</p>\n\n<p>Rilis untuk Fi Store waktunya sendiri tidak bersamaan dengan rislis Fiyo 1.4.0, karena senagja dijedakan beberapa hari untuk mengantisipasi update kecil pada Fiyo 1.4.0.</p>\n\n<h3>Sitemap XML Generator</h3>\n\n<p>Anda bisa melakukan pelacakan setiap url yang diciptakan dan merangkumnya dalam satu file XML yang bisa digunakan sebagai Sitemap. Fitur ini bisa digunakan dengan menggunakan <strong>Fi Sitemap</strong>.&nbsp;</p>\n\n<h3>Change Logs</h3>\n\n<ol>\n	<li>Penambahan fitur Sitemap &quot;XML&quot;.</li>\n	<li>Penambahan fitur perijinan regristrasi user baru.</li>\n	<li>Penambahan fitur reCaptcha dan captcha math.</li>\n	<li>Penambahan sistem rating untuk Article.</li>\n	<li>Penambahan biodata <em>Author</em> artikel (user).</li>\n	<li>Penambahan konfigurasi rating pada Article Parameter.</li>\n	<li>Penambahan konfigurasi layout artikel.</li>\n	<li>Penambahan fitur statistik.</li>\n	<li>Mengganti sistem penganggalan pada <em>Article</em>.</li>\n	<li>Mengganti nama fungsi&nbsp;<strong>dataConfig</strong>&nbsp;menjadi&nbsp;<strong>siteConfig</strong>.</li>\n	<li>Perbaikan fitur <strong>XML</strong> generat untuk <strong>RSS Feed.</strong></li>\n	<li>Perbaikan sistem Auto Installer.</li>\n</ol>\n","2013-03-01 01:42:46","","1","","Teknologi,CMS","","1","1","99","34051","show_comment=2;\nshow_author=2;\nshow_date=2;\nshow_category=0;\nshow_tags=1;\nshow_hits=1;\nshow_rate=1;\nrate_value=10;\nrate_counter=2;\npanel_top=2;\npanel_bottom=2;\neditor_level=1;\nshow_title=2;\n","2014-10-11 13:06:09","1");

--

DROP TABLE IF EXISTS `fiyo57_article_category`;

--

CREATE TABLE `fiyo57_article_category` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `parent_id` int(5) NOT NULL,
  `description` varchar(250) NOT NULL,
  `keywords` varchar(150) NOT NULL,
  `level` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=latin1;

--

INSERT INTO `fiyo57_article_category` (`id`,`name`,`parent_id`,`description`,`keywords`,`level`) VALUES ("1","Blog","0","Blog","Blog","99"),
("2","News","0","Berita Mengenai Kampus","Berita kampus","99"),
("3","Page","0","","","99"),
("55","Tutorial","0","","","99");

--

DROP TABLE IF EXISTS `fiyo57_article_tags`;

--

CREATE TABLE `fiyo57_article_tags` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(200) NOT NULL,
  `hits` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=79 DEFAULT CHARSET=latin1;

--

INSERT INTO `fiyo57_article_tags` (`id`,`name`,`description`,`hits`) VALUES ("49","Teknologi","","0"),
("50","House","","0"),
("76","CMS","","0"),
("77","Android","","0");

--

DROP TABLE IF EXISTS `fiyo57_comment`;

--

CREATE TABLE `fiyo57_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `link` varchar(250) NOT NULL,
  `user_id` int(5) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `website` varchar(100) NOT NULL,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `comment` text NOT NULL,
  `status` int(1) NOT NULL,
  `apps` varchar(50) NOT NULL,
  `parent_id` int(10) NOT NULL,
  `parent_user_email` varchar(50) NOT NULL,
  `thread_user_email` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=136 DEFAULT CHARSET=latin1;

--

INSERT INTO `fiyo57_comment` (`id`,`link`,`user_id`,`name`,`email`,`website`,`date`,`comment`,`status`,`apps`,`parent_id`,`parent_user_email`,`thread_user_email`) VALUES ("134","?app=article&view=item&id=14","0","Seem","seem@gmail.com","","2014-09-02 18:00:38","Semoga tambah jaya selalu min","1","article","1","1","1"),
("135","?app=article&view=item&id=12","1","Administrator","admin@admin.com","","2014-09-02 18:04:19","Benar juga gan!","1","article","1","1","1");

--

DROP TABLE IF EXISTS `fiyo57_comment_setting`;

--

CREATE TABLE `fiyo57_comment_setting` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `value` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--

INSERT INTO `fiyo57_comment_setting` (`id`,`name`,`value`) VALUES ("1","auto_submit","0"),
("2","name_filter","Admin, Administrator"),
("3","email_filter","email"),
("4","word_filter","anj, ngsat, sial, njin"),
("6","recaptcha_privatekey",""),
("5","recaptcha_publickey","");

--

DROP TABLE IF EXISTS `fiyo57_contact`;

--

CREATE TABLE `fiyo57_contact` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `gender` tinyint(1) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(20) NOT NULL,
  `country` varchar(20) NOT NULL,
  `zip` varchar(10) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `fax` varchar(20) NOT NULL,
  `job` varchar(100) NOT NULL,
  `photo` text NOT NULL,
  `web` varchar(30) NOT NULL,
  `ym` varchar(50) NOT NULL,
  `fb` varchar(50) NOT NULL,
  `tw` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `group_id` int(5) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--

INSERT INTO `fiyo57_contact` (`id`,`name`,`gender`,`email`,`address`,`city`,`state`,`country`,`zip`,`phone`,`fax`,`job`,`photo`,`web`,`ym`,`fb`,`tw`,`description`,`group_id`,`status`) VALUES ("1","First Ryan","1","firstryan@gmail.com","Jl. Selomulyo Mukti Timur VI\n\n\n\n444","Semarang","Jawa Tengah","Indonesia","50195","+62 898 578 578 7","","","/fiyo/media/images/brush.png","firstryan.net","firstryan@ymail.com","firstryan","firstryan","","1","1");

--

DROP TABLE IF EXISTS `fiyo57_contact_group`;

--

CREATE TABLE `fiyo57_contact_group` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--

INSERT INTO `fiyo57_contact_group` (`id`,`name`,`description`) VALUES ("1","Developer","Fiyo Developers ");

--

DROP TABLE IF EXISTS `fiyo57_gallery_album`;

--

CREATE TABLE `fiyo57_gallery_album` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `parent_id` int(5) NOT NULL,
  `cover` varchar(250) NOT NULL,
  `description` varchar(250) NOT NULL,
  `keywords` varchar(150) NOT NULL,
  `level` int(5) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--

INSERT INTO `fiyo57_gallery_album` (`id`,`name`,`parent_id`,`cover`,`description`,`keywords`,`level`,`status`) VALUES ("12","Administrator","0","/fiyo/media/images/dasboard.jpg","","","99","1");

--

DROP TABLE IF EXISTS `fiyo57_gallery_config`;

--

CREATE TABLE `fiyo57_gallery_config` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `value` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--

INSERT INTO `fiyo57_gallery_config` (`id`,`name`,`value`) VALUES 
--

DROP TABLE IF EXISTS `fiyo57_gallery_photo`;

--

CREATE TABLE `fiyo57_gallery_photo` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `category` int(5) NOT NULL,
  `photo` text NOT NULL,
  `date` datetime NOT NULL,
  `author` varchar(250) NOT NULL,
  `author_id` int(5) NOT NULL,
  `description` text NOT NULL,
  `tag` text NOT NULL,
  `featured` int(1) NOT NULL,
  `status` int(1) NOT NULL,
  `level` int(1) NOT NULL,
  `hits` int(10) NOT NULL,
  `parameter` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--

INSERT INTO `fiyo57_gallery_photo` (`id`,`title`,`category`,`photo`,`date`,`author`,`author_id`,`description`,`tag`,`featured`,`status`,`level`,`hits`,`parameter`) VALUES ("16","DJ Equipment Rental","12","/fiyo/media/images/dasboard.jpg","2014-10-01 01:09:00","","5","","","1","1","99","26","rate_value=5;\nrate_counter=2;\nrate_value=10;\n"),
("17","DJ Equipment Rental","12","/fiyo/media/images/login-default.jpg","2014-10-01 03:06:45","","5","","","1","1","99","19","rate_value=10;\nrate_counter=3;\nrate_value=10;\n"),
("18","Lumidians","12","/fiyo/media/images/10644100_839590032718190_8706335075921275267_o.jpg","2014-10-02 13:54:35","","5","","","1","1","99","37","rate_value=18;\nrate_counter=4;\n");

--

DROP TABLE IF EXISTS `fiyo57_menu`;

--

CREATE TABLE `fiyo57_menu` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `category` varchar(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `link` text NOT NULL,
  `app` varchar(100) NOT NULL,
  `parent_id` int(5) NOT NULL,
  `status` int(5) NOT NULL,
  `short` int(5) NOT NULL,
  `level` int(5) NOT NULL DEFAULT '3',
  `home` int(5) NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL,
  `show_title` int(2) NOT NULL,
  `sub_name` varchar(100) NOT NULL,
  `class` varchar(200) NOT NULL,
  `style` text NOT NULL,
  `parameter` text NOT NULL,
  `global` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=141 DEFAULT CHARSET=latin1;

--

INSERT INTO `fiyo57_menu` (`id`,`category`,`name`,`link`,`app`,`parent_id`,`status`,`short`,`level`,`home`,`title`,`show_title`,`sub_name`,`class`,`style`,`parameter`,`global`) VALUES ("2","mainmenu","About","?app=article&view=item&id=12","app_article","0","1","3","99","0","","0","","","","per_page=5;\nshow_panel=0;\nread_more=;\nimgW=120;\nimgH=100;\nformat=default;\nintro=5;\npanel_format=how_panel=0;\nshow_rss=1;\n","0"),
("3","mainmenu","Blog","?app=article&view=category&id=1","app_article","0","1","2","99","0","","0","","","","per_page=6;\nshow_panel=1;\nread_more=;\nimgW=120;\nimgH=100;\nformat=grid;\nintro=5;\npanel_format=;\nshow_rss=1;\n","0"),
("8","mainmenu","Contact","?app=contact&view=group&id=1","app_contact","0","1","5","99","0","","1","","","","per_page=10;\nshow_name=1;\nshow_group=1;\nshow_gender=0;\nshow_address=0;\nshow_phone=0;\nshow_email=0;\nshow_links=0;\nshow_job=0;\nshow_photo=0;\n","0"),
("23","mainmenu","Home","?app=article&view=archives","app_article","0","1","0","99","1","","1","","","","per_page=6;\nshow_panel=1;\nread_more=;\nimgW=200;\nimgH=150;\nformat=grid;\nintro=4;\npanel_format=;\nshow_rss=1;\n","1"),
("41","mainmenu","Sub Child","?app=article&view=category&id=1","app_article","103","1","0","99","0","","1","","","","per_page=5;\nshow_panel=0;\nread_more=;\nimgW=120;\nimgH=100;\nformat=default;\nintro=5;\npanel_format=;\nshow_rss=0;\n","0"),
("18","mainmenu","Category","?app=article&view=item&id=10","app_article","0","1","1","99","0","","0","","","","per_page=5;\nshow_panel=0;\nread_more=;\nimgW=120;\nimgH=100;\nformat=default;\nintro=5;\npanel_format=;\nshow_rss=0;\n","0"),
("42","footer","First Ryan","?app=article&view=item&id=5","app_article","0","0","0","99","0","","1","","","","per_page=5;\nshow_panel=0;\nread_more=;\nimgW=120;\nimgH=100;\nformat=default;\nintro=5;\npanel_format=;\nshow_rss=0;\n","0"),
("108","footer","asd","?app=article&view=featured","app_article","0","1","0","99","0","","1","","","","","0"),
("55","adminpanel","Dashboard","index.php","link","0","1","0","3","0","","1","","icon-home","","","0"),
("56","adminpanel","Articles","#","sperator","0","1","1","5","0","","1","article","icon-file-text","","","0"),
("57","adminpanel","New Article","?app=article&act=add","link","56","1","0","3","0","","1","","icon-plus","","","0"),
("63","adminpanel","Comments","?app=article&view=comment","link","56","1","3","3","0","","1","","icon-comments","","","0"),
("61","adminpanel","Article List","?app=article","link","56","1","1","99","0","","1","","icon-list-alt","","","0"),
("62","adminpanel","Categories","?app=article&view=category","link","56","1","2","2","0","","1","","icon-book","","","0"),
("64","adminpanel","Tags","?app=article&view=tag","link","56","1","4","3","0","","1","","icon-tag","","","0"),
("65","adminpanel","Apps","#","sperator","0","1","2","3","0","","1","apps","icon-star","","","0"),
("66","adminpanel","File Manager","#","sperator","0","1","5","99","0","","1","media","icon-folder-open","","","0"),
("67","adminpanel","Images","?app=media","link","66","1","1","5","0","","1","","icon-picture","","","0"),
("68","adminpanel","Videos","?app=media&type=flash","link","66","1","1","5","0","","1","","icon-facetime-video","","","0"),
("87","adminpanel","Backup & Restore","?app=config&view=backup","link","83","1","3","1","0","","1","","icon-repeat","","","0"),
("69","adminpanel","Other Files","?app=media&type=files","link","66","1","2","5","0","","1","","icon-file","","","0"),
("70","adminpanel","Menus","#","sperator","0","1","6","2","0","","1","menu","icon-list-ul","","","0"),
("71","adminpanel","New Menu","?app=menu&view=add","link","70","1","0","2","0","","1","","icon-plus","","","0"),
("72","adminpanel","Menu List","?app=menu","link","70","0","1","2","0","","1","","icon-list-alt","","","0"),
("73","adminpanel","Categories","?app=menu&view=category","link","70","1","2","2","0","","1","","icon-book","","","0"),
("74","adminpanel","Modules","?app=module","link","0","1","7","2","0","","1","module","icon-inbox","","","0"),
("75","adminpanel","Themes","#","sperator","0","1","8","2","0","","1","theme","icon-magic","","","0"),
("76","adminpanel","Front End","?app=theme","link","75","1","0","2","0","","1","","icon-desktop","","","0"),
("77","adminpanel","Admin Panel","?app=theme&view=admin","link","75","1","2","2","0","","1","","icon-laptop","","","0"),
("78","adminpanel","Users","#","sperator","0","1","9","2","0","","1","user","icon-user","","","0"),
("79","adminpanel","New User","?app=user&act=add","link","78","1","0","2","0","","1","","icon-plus","","","0"),
("80","adminpanel","User List","?app=user","link","78","1","2","2","0","","1","","icon-list-alt","","","0"),
("81","adminpanel","User Group","?app=user&view=group","link","78","1","3","2","0","","1","","icon-group","","","0"),
("82","adminpanel","Plugins","?app=plugin","link","0","1","10","2","0","","1","plugin","icon-bolt","","","0"),
("83","adminpanel","Settings","#","sperator","0","1","11","2","0","","1","config","icon-cog","","","0"),
("84","adminpanel","Configuration","?app=config","link","83","1","0","2","0","","1","","icon-cogs","","","0"),
("85","adminpanel","Manages","?app=config&view=apps","link","83","1","2","1","0","","1","","icon-th","","","0"),
("86","adminpanel","Install & Update","?app=config&view=install","link","83","1","3","1","0","","1","","icon-download-alt","","","0"),
("89","adminpanel","Sitemap","?app=sitemap","link","65","1","20","2","0","","1","","icon-sitemap","","","0"),
("90","adminpanel","Permalink","?app=permalink","link","65","1","0","2","0","","1","","icon-link","","","0"),
("92","adminpanel","Contact","?app=contact","link","65","1","0","99","0","","1","","icon-group","ooo","","0"),
("103","mainmenu","Child Menu","#","sperator","18","1","0","99","0","","1","","","","","0"),
("105","mainmenu","Very Child","#","sperator","41","1","0","99","0","","1","","","","","0"),
("107","footer","Contact","?app=article&view=featured","app_article","42","1","0","99","0","","1","","","","per_page=5;\nshow_panel=0;\nread_more=;\nimgW=120;\nimgH=100;\nformat=default;\nintro=5;\npanel_format=;\nshow_rss=0;\n","0"),
("110","mainmenu","Gallery","?app=gallery&view=default","app_gallery","0","1","0","99","0","","1","","","","per_page=5;\nshow_panel=0;\nread_more=;\nimgW=120;\nimgH=100;\nformat=;\nintro=0;\npanel_format=;\nshow_rss=0;\n","0"),
("140","adminpanel","Gallery","?app=gallery","app_gallery","65","1","0","3","0","","1","gallery","icon-camera","","","0");

--

DROP TABLE IF EXISTS `fiyo57_menu_category`;

--

CREATE TABLE `fiyo57_menu_category` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(200) NOT NULL,
  `level` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_2` (`category`),
  UNIQUE KEY `category_3` (`category`),
  KEY `category` (`category`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

--

INSERT INTO `fiyo57_menu_category` (`id`,`category`,`title`,`description`,`level`) VALUES ("1","mainmenu","Main Menu","Menu utama","2"),
("2","footer","Footer Menu","","99"),
("9","adminpanel","Admin Panel","Menu for Admin Panel","1");

--

DROP TABLE IF EXISTS `fiyo57_module`;

--

CREATE TABLE `fiyo57_module` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `folder` varchar(150) NOT NULL,
  `position` varchar(100) NOT NULL,
  `short` int(2) NOT NULL,
  `level` int(2) NOT NULL DEFAULT '3',
  `status` int(2) NOT NULL DEFAULT '1',
  `page` varchar(250) NOT NULL,
  `parameter` text NOT NULL,
  `class` varchar(200) NOT NULL,
  `style` text NOT NULL,
  `show_title` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=123 DEFAULT CHARSET=latin1;

--

INSERT INTO `fiyo57_module` (`id`,`name`,`folder`,`position`,`short`,`level`,`status`,`page`,`parameter`,`class`,`style`,`show_title`) VALUES ("1","Menu","mod_menu","mainmenu","0","99","1","23,110,18,41,3,2,8,42","category=mainmenu;\ntype=2;\nsub_menu=1;\nsub_title=0;\n","","","0"),
("121","Tags","mod_article_tags","right","2","99","0","23,18,103,41,3,2,8,42,104","","","","1"),
("118","Search","mod_search","search","0","99","0","23,18,41,3,2,8,42","","","","0"),
("5","You are here : ","mod_breadcrumb","top1","0","99","1","23,18,41,3,2,8,42","","","","0"),
("6","Comments","mod_comment","right","2","99","0","23,18,41,3,2,8,42","name=1;\ngravatar=1;\ntitle=1;\ncomment=0;\ndate=1;\ntext=100;\nitem=5;\n","","","1"),
("119","Statistic","mod_statistic","right","3","99","0","23,18,41,3,2,8,42","today=1;\nyesterday=1;\nthisweek=1;\nlastweek=1;\nthismonth=1;\nlastmonth=1;\nall=0;\ninfo=0;\n","","","1"),
("96","Next","mod_article_nextprev","article-mid","0","99","1","23,18,41,36,49,93,3,2,8,42,40,43,48,96,97,98","cat=1,2,3,55;\nfilter=;\n","","","0"),
("120","User Panel","mod_user","right","0","99","0","23,18,41,3,2,8,42","","","","1"),
("122","DJ Equipment Rental","mod_article_nextprev","top2","0","99","1","23,110,18,103,41,105,3,2,8,42,107,108","cat=;\nfilter=;\n","","","1");

--

DROP TABLE IF EXISTS `fiyo57_permalink`;

--

CREATE TABLE `fiyo57_permalink` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `link` text NOT NULL,
  `permalink` varchar(250) NOT NULL,
  `pid` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `locker` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permalink` (`permalink`)
) ENGINE=MyISAM AUTO_INCREMENT=304 DEFAULT CHARSET=latin1;

--

INSERT INTO `fiyo57_permalink` (`id`,`link`,`permalink`,`pid`,`status`,`locker`) VALUES ("232","?app=article&view=archives&feed=rss","archives.rss","41","1","0"),
("231","?app=article&view=item&id=17","blog/fiyo-cms-1-5-5.html","3","1","0"),
("230","?app=article&view=category&id=1","blog","3","1","0"),
("233","?app=article&view=item&id=14","blog/fiyo-cms-1-5-0.html","3","1","0"),
("234","?app=article&view=item&id=6","blog/fiyo-1-2-2-dengan-fitur-lebih-canggih.html","3","1","0"),
("235","?app=article&view=item&id=175","blog/fiyo-cms-1-4-0.html","3","1","0"),
("240","?app=user","user","3","1","0"),
("238","?app=user&view=logout","user/logout","3","1","0"),
("241","?app=user&view=edit","user/edit","3","1","0"),
("242","?app=user&view=login","user/login","3","1","0"),
("243","?app=user&view=register","user/register","3","1","0"),
("244","?app=user&view=lost_password","user/remember","3","1","0"),
("245","?app=search","search","3","1","0"),
("246","?app=contact&view=group&id=1","contact/developer","8","1","0"),
("247","?app=article&view=item&id=12","blog/mengenal-lebih-dekat-tentang-fiyo-cms.html","3","1","0"),
("248","?app=contact&view=person&id=1","contact/developer/first-ryan.html","3","1","0"),
("249","?app=article&tag=Home","tag/home","3","1","0"),
("250","?app=article&tag=CMS","tag/cms","3","1","0"),
("251","?app=article&view=item&id=182","news/fiyo-cms-1-5-7-3-0.html","3","1","0"),
("252","?app=article&view=category&id=2","news","3","1","0"),
("253","?app=article&view=item&id=10","news/fiyo-cms-1-3-0.html","3","1","0"),
("254","?app=article&view=item&id=7","blog/update-checkpoint-di-versi-1-2-3.html","3","1","0"),
("255","?app=article&tag=Review","tag/review","3","1","0"),
("256","?app=article&tag=Review&feed=rss","tag/review.rss","3","1","0"),
("257","?app=article&tag=Teknologi","tag/teknologi","3","1","0"),
("258","?app=article&tag=Teknologi&feed=rss","tag/teknologi.rss","3","1","0"),
("259","?app=article&view=category&id=2&feed=rss","news.rss","3","1","0"),
("260","?app=article&tag=CMS&feed=rss","tag/cms.rss","3","1","0"),
("261","?app=article&view=category&id=1&feed=rss","blog.rss","3","1","0"),
("262","?app=article&view=item&id=183","blog/apa-saja-yang-baru-di-fiyo-2-0.html","3","1","0"),
("263","?app=contact","contact","8","1","0"),
("264","?app=article&amp;view=item&amp;id=182","news/fiyo-cms-1-5-7-3-0-2.html","23","1","0"),
("265","?app=article&amp;view=item&amp;id=175","blog/fiyo-cms-1-4-0-2.html","3","1","0"),
("266","?app=article&amp;view=item&amp;id=10","news/fiyo-cms-1-3-0-2.html","23","1","0"),
("267","?app=article&amp;view=item&amp;id=183","blog/apa-saja-yang-baru-di-fiyo-2-0-2.html","3","1","0"),
("268","?app=article&amp;view=item&amp;id=17","blog/fiyo-cms-1-5-5-2.html","3","1","0"),
("269","?app=article&amp;view=item&amp;id=14","blog/fiyo-cms-1-5-0-2.html","3","1","0"),
("270","?app=article&amp;view=item&amp;id=7","blog/update-checkpoint-di-versi-1-2-3-2.html","3","1","0"),
("271","?app=article&amp;view=item&amp;id=12","blog/mengenal-lebih-dekat-tentang-fiyo-cms-2.html","3","1","0"),
("272","?app=article&amp;view=item&amp;id=6","blog/fiyo-1-2-2-dengan-fitur-lebih-canggih-2.html","3","1","0"),
("273","?app=article&view=item&id=4","blog/fitur-baru-di-v-1-2-0.html","3","1","0"),
("274","?app=article&amp;view=item&amp;id=4","blog/fitur-baru-di-v-1-2-0-2.html","3","1","0"),
("275","?app=article&view=item&id=1","blog/fiyo-cms-hadir-pada-tahun-2012.html","3","1","0"),
("276","?app=article&view=item&id=8","blog/membuat-template-fiyocms.html","3","1","0"),
("277","?app=article&amp;view=item&amp;id=1","blog/fiyo-cms-hadir-pada-tahun-2012-2.html","3","1","0"),
("278","?app=article&amp;view=item&amp;id=8","blog/membuat-template-fiyocms-2.html","3","1","0"),
("279","?app=gallery&view=default","gallery","110","1","0"),
("290","?app=gallery&view=item&id=7","gallery/administrator/tetteet.html","110","1","0"),
("289","?app=gallery&view=item&id=5","gallery/administrator/aaaa.html","110","1","0"),
("288","?app=gallery&view=category&id=1","gallery/administrator","110","1","0"),
("291","?app=gallery&view=category&id=2","gallery/a","110","1","0"),
("292","?app=gallery&view=category&id=3","gallery/test","110","1","0"),
("293","?app=gallery&view=category&id=4","gallery/aaasd","110","1","0"),
("294","?app=gallery&view=item&id=9","gallery/admin-panel-galelry/admin-panel-biru-kota-megah.html","110","1","0"),
("295","?app=gallery&view=category&id=5","gallery/asdsd","110","1","0"),
("296","?app=gallery&view=item&id=10","gallery/admin-panel-galelry/admin-panel-batik.html","110","1","0"),
("297","?app=gallery&view=item&id=11","gallery/admin-panel-galelry/admin-panel-warna-warni.html","110","1","0"),
("298","?app=gallery&view=item&id=12","gallery/admin-panel-galelry/modul-kontrol-temperatur-air-berbasis-pid-menggunakan-matlab-simulink.html","110","1","0"),
("299","?app=gallery&view=category&id=12","gallery/administrator-2.html","110","1","0"),
("300","?app=gallery&view=item&id=16","gallery/administrator/dj-equipment-rental.html","110","1","0"),
("301","?app=gallery&view=item&id=17","gallery/administrator/dj-equipment-rental-2.html","110","1","0"),
("302","?app=gallery&view=item&id=18","gallery/administrator/lumidians.html","110","1","0"),
("303","?app=article&view=item&id=195","blog/program-studi.html","3","1","0");

--

DROP TABLE IF EXISTS `fiyo57_plugin`;

--

CREATE TABLE `fiyo57_plugin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `folder` varchar(20) NOT NULL,
  `status` smallint(1) NOT NULL,
  `parameter` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `folder_2` (`folder`),
  KEY `folder` (`folder`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--

INSERT INTO `fiyo57_plugin` (`id`,`folder`,`status`,`parameter`) VALUES ("1","plg_sef","1",""),
("2","plg_cache","1",""),
("3","plg_recaptcha","1",""),
("4","plg_statistic","1","");

--

DROP TABLE IF EXISTS `fiyo57_session_login`;

--

CREATE TABLE `fiyo57_session_login` (
  `user_id` int(11) NOT NULL,
  `session_id` varchar(100) NOT NULL,
  `level` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--

INSERT INTO `fiyo57_session_login` (`user_id`,`session_id`,`level`,`time`) VALUES ("6","demo","3","2014-09-22 11:47:04"),
("5","admin","1","2014-10-11 13:15:42");

--

DROP TABLE IF EXISTS `fiyo57_setting`;

--

CREATE TABLE `fiyo57_setting` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

--

INSERT INTO `fiyo57_setting` (`id`,`name`,`value`) VALUES ("1","site_theme","curve"),
("2","admin_theme","fiyo"),
("3","site_name","Admin"),
("4","site_keys","keyword 1, keyword two, 3rd key"),
("5","site_desc","admin"),
("6","site_title","Fast, Save & Elegant!"),
("7","site_url","localhost"),
("8","site_status","1"),
("9","sef_url","1"),
("10","file_allowed","swf flv avi mpg mpeg qt mov wmv asf rm rar zip exe msi iso"),
("11","file_size","5120"),
("12","media_theme","oxygen"),
("13","title_type","1"),
("14","title_divider"," - "),
("15","sef_www","1"),
("16","sef_ext",".html"),
("17","site_mail","your@site.net"),
("18","backend_folder","dapur"),
("19","follow_link","1"),
("20","member_registration","1"),
("21","member_activation","2"),
("22","member_group","3"),
("23","version","2.0 1.2"),
("24","lang","id"),
("25","timezone","Asia/Jakarta"),
("26","api_key","500"),
("27","disk_space","5000");

--

DROP TABLE IF EXISTS `fiyo57_statistic`;

--

CREATE TABLE `fiyo57_statistic` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ip` varchar(20) NOT NULL,
  `user_id` int(10) NOT NULL,
  `time` datetime NOT NULL,
  `browser` varchar(30) NOT NULL,
  `platform` varchar(30) NOT NULL,
  `country` varchar(15) NOT NULL,
  `city` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;

--

INSERT INTO `fiyo57_statistic` (`id`,`ip`,`user_id`,`time`,`browser`,`platform`,`country`,`city`) VALUES ("1","127.0.0.1","1","2014-09-12 23:45:41","Chrome","Windows","Local","Local"),
("2","127.0.0.1","1","2014-09-13 00:04:46","Chrome","Windows","Local","Local"),
("3","127.0.0.1","0","2014-09-13 11:40:06","Chrome","Windows","Local","Local"),
("4","127.0.0.1","1","2014-09-16 13:06:47","Chrome","Windows","Local","Local"),
("5","127.0.0.1","1","2014-09-16 17:11:48","Chrome","Windows","Local","Local"),
("6","127.0.0.1","1","2014-09-17 00:34:00","Chrome","Windows","Local","Local"),
("7","127.0.0.1","0","2014-09-17 12:05:40","Chrome","Windows","Local","Local"),
("8","127.0.0.1","1","2014-09-17 14:31:55","Chrome","Windows","Local","Local"),
("9","127.0.0.1","1","2014-09-17 16:33:21","Chrome","Windows","Local","Local"),
("10","127.0.0.1","1","2014-09-17 22:47:43","Chrome","Windows","Local","Local"),
("11","127.0.0.1","1","2014-09-18 00:42:03","Chrome","Windows","Local","Local"),
("12","127.0.0.1","1","2014-09-18 11:38:45","Chrome","Windows","Local","Local"),
("13","127.0.0.1","0","2014-09-18 12:16:02","Msie","Windows","Local","Local"),
("14","127.0.0.1","0","2014-09-18 13:47:11","Chrome","Windows","Local","Local"),
("15","127.0.0.1","1","2014-09-18 23:11:24","Chrome","Windows","Local","Local"),
("16","127.0.0.1","1","2014-09-19 01:38:06","Chrome","Windows","Local","Local"),
("17","127.0.0.1","1","2014-09-19 23:32:33","Chrome","Windows","Local","Local"),
("18","127.0.0.1","1","2014-09-20 01:26:11","Chrome","Windows","Local","Local"),
("19","127.0.0.1","1","2014-09-20 11:45:57","Chrome","Windows","Local","Local"),
("20","127.0.0.1","0","2014-09-20 11:55:39","Msie","Windows","Local","Local"),
("21","127.0.0.1","1","2014-09-20 12:34:21","Chrome","Windows","Local","Local"),
("22","127.0.0.1","1","2014-09-20 15:50:58","Chrome","Windows","Local","Local"),
("23","127.0.0.1","1","2014-09-20 23:46:55","Chrome","Windows","Local","Local"),
("24","127.0.0.1","1","2014-09-21 00:57:25","Chrome","Windows","Local","Local"),
("25","127.0.0.1","1","2014-09-21 11:45:52","Chrome","Windows","Local","Local"),
("26","127.0.0.1","1","2014-09-21 15:22:21","Chrome","Windows","Local","Local"),
("27","127.0.0.1","1","2014-09-21 17:30:13","Chrome","Windows","Local","Local"),
("28","127.0.0.1","1","2014-09-22 00:09:11","Chrome","Windows","Local","Local"),
("29","127.0.0.1","2","2014-09-22 11:30:09","Chrome","Windows","Local","Local"),
("30","127.0.0.1","5","2014-09-23 00:15:08","Chrome","Windows","Local","Local"),
("31","127.0.0.1","5","2014-09-23 12:16:33","Chrome","Windows","Local","Local"),
("32","127.0.0.1","0","2014-09-26 22:08:57","Chrome","Windows","Local","Local"),
("33","127.0.0.1","0","2014-09-30 02:06:56","Chrome","Windows","Local","Local"),
("34","127.0.0.1","0","2014-09-30 02:10:56","Chrome","Windows","Local","Local"),
("35","127.0.0.1","5","2014-09-30 09:14:49","Chrome","Windows","Local","Local"),
("36","127.0.0.1","5","2014-09-30 11:14:51","Chrome","Windows","Local","Local"),
("37","127.0.0.1","5","2014-09-30 13:15:17","Chrome","Windows","Local","Local"),
("38","127.0.0.1","0","2014-09-30 23:48:11","Chrome","Windows","Local","Local"),
("39","127.0.0.1","5","2014-10-01 01:09:18","Chrome","Windows","Local","Local"),
("40","127.0.0.1","5","2014-10-01 03:59:13","Chrome","Windows","Local","Local"),
("41","127.0.0.1","0","2014-10-02 13:51:22","Chrome","Windows","Local","Local"),
("42","127.0.0.1","0","2014-10-03 00:21:23","Chrome","Windows","Local","Local"),
("43","127.0.0.1","0","2014-10-06 23:12:13","Chrome","Windows","Local","Local"),
("44","127.0.0.1","0","2014-10-10 00:08:36","Chrome","Windows","Local","Local"),
("45","127.0.0.1","5","2014-10-10 04:46:16","Chrome","Windows","Local","Local"),
("46","127.0.0.1","5","2014-10-10 22:08:39","Chrome","Windows","Local","Local"),
("47","127.0.0.1","5","2014-10-11 00:00:22","Chrome","Windows","Local","Local"),
("48","127.0.0.1","5","2014-10-11 09:15:32","Chrome","Windows","Local","Local"),
("49","127.0.0.1","0","2014-10-11 10:26:16","Firefox","Windows","Local","Local"),
("50","127.0.0.1","5","2014-10-11 11:21:24","Chrome","Windows","Local","Local");

--

DROP TABLE IF EXISTS `fiyo57_statistic_online`;

--

CREATE TABLE `fiyo57_statistic_online` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(20) NOT NULL,
  `url` tinytext NOT NULL,
  `time` int(11) NOT NULL,
  `browser` varchar(20) NOT NULL,
  `platform` varchar(20) NOT NULL,
  `country` varchar(30) NOT NULL,
  `city` varchar(50) NOT NULL,
  `key` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=235 DEFAULT CHARSET=latin1;

--

INSERT INTO `fiyo57_statistic_online` (`id`,`ip`,`url`,`time`,`browser`,`platform`,`country`,`city`,`key`) VALUES 
--

DROP TABLE IF EXISTS `fiyo57_user`;

--

CREATE TABLE `fiyo57_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` int(2) NOT NULL,
  `level` int(11) NOT NULL DEFAULT '3',
  `time_reg` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `time_log` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `about` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user` (`user`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--

INSERT INTO `fiyo57_user` (`id`,`user`,`name`,`password`,`email`,`status`,`level`,`time_reg`,`time_log`,`about`) VALUES ("5","admin","Administrator","21232f297a57a5a743894a0e4a801fc3","admin@admin.com","1","1","2014-09-22 11:34:00","2014-10-11 13:15:42",""),
("2","admin2","Administrator","21232f297a57a5a743894a0e4a801fc3","admin@admin2.com","1","1","2014-09-22 11:03:03","2014-09-22 11:03:09",""),
("6","demo","Developer","fe01ce2a7fbac8fafaed7c982a04e229","demo@gmail.com","1","3","2014-09-22 11:46:53","2014-09-22 11:47:04","");

--

DROP TABLE IF EXISTS `fiyo57_user_group`;

--

CREATE TABLE `fiyo57_user_group` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(50) NOT NULL,
  `level` int(2) NOT NULL,
  `description` text NOT NULL,
  `allowed_apps` varchar(200) NOT NULL,
  `default_apps` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `level` (`level`),
  KEY `group` (`group_name`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

--

INSERT INTO `fiyo57_user_group` (`id`,`group_name`,`level`,`description`,`allowed_apps`,`default_apps`) VALUES ("1","Super Administrator","1","Super Administrator","",""),
("2","Administrator","2","Admin","",""),
("10","asdasd","3","","",""),
("33","Member","4","aaewe","","");

--

DROP TABLE IF EXISTS `db_prefix_apps`;

--

CREATE TABLE `db_prefix_apps` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `folder` varchar(200) NOT NULL,
  `author` varchar(50) NOT NULL,
  `type` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

--

INSERT INTO `db_prefix_apps` (`id`,`name`,`folder`,`author`,`type`) VALUES ("1","Article","app_article","Fiyo CMS","0"),
("2","Comment","app_comment","Fiyo CMS","2"),
("3","User","app_user","Fiyo CMS","0"),
("4","Search","app_search","Fiyo CMS","2"),
("5","Contact","app_contact","Fiyo CMS","1"),
("6","Permalink","app_sef","Fiyo CMS","2"),
("7","Sitemap","app_sitemap","Fiyo CMS","2"),
("34","Gallery","app_gallery","Fiyo Developers","1");

--

DROP TABLE IF EXISTS `db_prefix_article`;

--

CREATE TABLE `db_prefix_article` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `category` int(5) NOT NULL,
  `article` text NOT NULL,
  `date` datetime NOT NULL,
  `author` varchar(250) NOT NULL,
  `author_id` int(5) NOT NULL,
  `description` text NOT NULL,
  `tags` text NOT NULL,
  `keyword` text NOT NULL,
  `featured` int(1) NOT NULL,
  `status` int(1) NOT NULL,
  `level` int(1) NOT NULL,
  `hits` int(10) NOT NULL,
  `parameter` text NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `editor` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=196 DEFAULT CHARSET=latin1;

--

INSERT INTO `db_prefix_article` (`id`,`title`,`category`,`article`,`date`,`author`,`author_id`,`description`,`tags`,`keyword`,`featured`,`status`,`level`,`hits`,`parameter`,`updated`,`editor`) VALUES ("1","Fiyo CMS Hadir pada Tahun 2012","1","<p>Welcome :)</p>\n","2012-01-04 14:54:58","First Ryan","1","gyi","","","1","1","99","763","show_comment=0;\nshow_author=2;\nshow_date=2;\nshow_category=2;\nshow_tags=2;\nshow_hits=2;\nshow_rate=2;\nrate_value=47;\nrate_counter=11;\npanel_top=0;\npanel_bottom=1;\neditor_level=3;\nshow_title=0;\n","2014-09-20 11:55:43","1"),
("4","Fitur Baru di V.1.2.0","1","<p>Meski sebenarnya belum rilis versi stabel, tetapi v.1.2.0 sudah bisa digunakan. Hanya saja butuh sedikit penyempurnaan. Apalagi versi ini hampir setengah codingnya berbeda dengan versi sebelumnya yang masih bersifat <em>jadul</em>.</p>\n\n<p>Berkat komentar dan masukan dari para ahlinya dan para sahabat ditambah para pengguna Fiyo yang antusias selalu memberikan kritik dan saran. Fiyo mengalami kemajuan dalam pengolahan data dan koding yang di kompres banyak dari versi sebelumnya.</p>\n\n<p>Installer yang hanya berjalan normal hanya di sebagian software localhost seperti di XAMPP dan WAMPP, tetapi tidak dapat mulus di Zend sudah sedikit diatasi di versi terbaru ini.</p>\n\n<hr id=\'system-readmore\' />\n<p>Berikut Fitur tambahan dan log di versi terbaru <strong>Fiyo v.1.2.0</strong></p>\n\n<h4>AddOns Intaller</h4>\n\n<p>Anda dapat memasang AddOns yang tersedia di situs resmi <strong>Fiyo.Org&nbsp;</strong>dan menginstalnya langsung di situs anda. AddOns adalah sebuah ekstensi tambahan yang ada di FiyoCMS seperti,<em> theme, module, plugin, apps.&nbsp;</em>Tetapi Anda harus sabar jika ingin mengambil AddOns di situs resminya, karena belum tersedia secara langsung dan masih dalam tahap penyempurnaan untuk situs Fiyo.Org itu sendiri.</p>\n\n<p>&nbsp;</p>\n\n<h4>Spot Position</h4>\n\n<p>Fitur ini memudahkan anda untuk mencari letak posisi modul pada theme anda, dengan hanya memilih gambar yang ada, dan tidak hanya tulisam saja. Fitur ini bisa anda temukan pada <strong>Module Manager</strong> dan <strong>Theme Manager.</strong></p>\n\n<p>&nbsp;</p>\n\n<p><strong>Work Logs Fiyo CMS</strong></p>\n\n<ol>\n	<li>pembenahan posisi modul pada modul manager belum akurat<em><span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span>1.1.0<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span>6-Jan-2012<span class=\'Apple-tab-span\' style=\'white-space: pre; \'> </span></em></li>\n	<li>merapikan tapilan tabel pada saat memilih &quot;single article&quot; di Menu Manager<span class=\'Apple-tab-span\' style=\'white-space: pre; \'> </span><em>1.1.0<span class=\'Apple-tab-span\' style=\'white-space: pre; \'> </span>6-Jan-2012</em></li>\n	<li>Penambahan menu AddOns Manager pada admin panel<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span><em>1.2.0<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span>7-Jan-2012</em></li>\n	<li>penambahan fitur AddOns Instaler<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span><em>1.2.0<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span>7-Jan-2012</em></li>\n	<li>penambahan fitur Apps AddOns<em><span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span>1.2.0<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span>8-Jan-2012</em></li>\n	<li>penambahan fitur Modules AddOns<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span><em>1.2.0<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span>8-Jan-2012</em></li>\n	<li>penambahan fitur Themes AddOns<em><span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span>1.2.0<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span>8-Jan-2012</em></li>\n</ol>\n\n<h4>Developer Logs Updated</h4>\n\n<ol>\n	<li>mark-up app_module untuk back-end<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span><em>6-Jan-2012</em></li>\n	<li>mark-up app_menu untuk back-end<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span><em>6-Jan-2012</em></li>\n	<li>penambahan fungsi extrak file zip -&gt; extractZip($file,$directory);<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span><em>8-Jan-2012</em></li>\n	<li>penambahan fungsi hapus direktori dan isinya -&gt; delete_directory($dirname);<span class=\'Apple-tab-span\' style=\'white-space:pre\'> </span><em>8-Jan-2012</em></li>\n</ol>\n\n<div>\n<h4>Issue</h4>\n\n<div>\n<ul>\n	<li>link kress (#) tidak berjalan&nbsp;<em><strong>solved</strong></em></li>\n	<li>posisi modul pada modul manager belum akurat&nbsp;<em><strong>solved</strong></em></li>\n	<li>Fiyo Installer tidak berjalan normal&nbsp;<em><strong>solved</strong></em></li>\n</ul>\n</div>\n</div>\n\n<p>&nbsp;</p>\n","2012-02-04 11:13:29","","1","","","","0","1","99","547","show_comment=2;\nshow_author=2;\nshow_date=2;\nshow_category=2;\nshow_tags=2;\nshow_hits=2;\nshow_rate=2;\nrate_value=19;\nrate_counter=3;\npanel_top=0;\npanel_bottom=0;\neditor_level=1;\n","2014-09-20 11:55:42","1"),
("6","Fiyo 1.2.2 dengan Fitur Lebih Canggih","1","<p><span style=\'line-height: 1.6em;\'>Rilis kali ini mempunyai perubahan yang signifikan dari rilis-update sebelumnya. Kali ini fitur yang ingin ditambahkan dari awal pembuatan FiyoCMS baru bisa dirasakan di versi 1.2.2 ini.</span></p><div style=\'page-break-after: always;\' contenteditable=\'false\' class=\'cke_pagebreak\' data-cke-display-name=\'pagebreak\' aria-label=\'Page Break\' title=\'Page Break\'></div><p>Yaitu fitur OneClickCange, dengan fitur ini mengatur artikel, menu dan modul terasa sangat mudah. Satu klik tanpa loading anda sudah bisa mengaktifkan atau menon-aktifkan artikel, modul atau menu yang anda inginkan.</p><p>Ditambah lagi di versi ini kita sudah bisa menyediakan module SlideShow, modul MultiFacebook, ImageScroll dan modul menarik lainya.</p><p>Pada versi ini juga ditambahkan Apps baru, yaitu App Contact. Anda bisa mengelola kontak para teman anda atau pegawai perusahaan.</p><p>Berikut Perubahan dan Fitur tambahan yang ada di Fiyo v 1.2.2</p><p><em><strong>Work Logs Fiyo CMS</strong></em></p><ul><li>penambahan plugins From Validator (JQuery)</li><li>penambahan plugins input limiter (JQuery)</li><li>fitur one click change pada Apps di AdminPanel&nbsp;&nbsp;(JQuery)</li><li>penyempurnaan plugin_sef</li><li>perbaikan : app_comment</li><li>perbaikan : app_article</li><li>penambahan : app_contact</li><li>perbaikan : app_user &nbsp;(Front Site)</li><li>perbaikan : app_module (Front Site)</li></ul><p><em><strong>Developer Logs Updates</strong></em></p><ul><li>Mengganti Field \'<strong>name</strong>\' dengan&nbsp;<strong>\'title</strong>\' pada tabel Article</li><li>penambahan fungsi&nbsp;<strong>get_htmlTag()</strong>&nbsp;sebagai fungsi tag parse</li></ul><p><br></p>","2012-02-19 13:00:29","","1","","","","1","1","99","463","show_comment=2;\nshow_author=2;\nshow_date=2;\nshow_category=1;\nshow_tags=2;\nshow_hits=2;\nshow_rate=2;\nrate_value=31;\nrate_counter=7;\npanel_top=0;\npanel_bottom=0;\neditor_level=2;\nshow_title=0;\n","2014-10-11 12:12:48","1"),
("7","Update checkpoint di versi 1.2.3","1","<p><span style=\'line-height: 1.6em;\'>Akhirnya setelah menunggu dan melakukan penambahan serta revisi dibagian system. Fiyo 1.2.3 dapat segera kami rilis. versi ini kami sebut dengan nama &nbsp;Fiyo one-two-three. Versi ini adalah yang terakhir untuk versi 1.2, yang berarti tidak akan ada lagi update untuk versi 1.2.x berikutnya.</span></p><p><span style=\'line-height: 1.6em;\'><img alt=\'\' data-cke-saved-src=\'/fiyo/media/images/login-blue.jpg\' src=\'/fiyo/media/images/login-blue.jpg\' style=\'width: 800px; height: 511px;\'></span></p><p>Walaupun masih ada beberapa fitur yang masih ingin ditambahkan seperti newsteller, dan fitur rating artikel. Tetapi ini diharap bisa menutup untuk versi 1.2 dan menjadikan Fiyo lebih dapat berkambang lebih canggih lagi.</p><div style=\'page-break-after: always;\' contenteditable=\'false\' class=\'cke_pagebreak\' data-cke-display-name=\'pagebreak\' aria-label=\'Page Break\' title=\'Page Break\'></div><p>Ok, berikut adalah fitur baru yang dimiliki Fiyo one-two-three.</p><h3>Add-Ons Manager Update</h3><p>Fitur Add-Ons Manager memang sudah lama ada, tetapi ada beberapa yang belum kami aktifkan. Tapi untuk saat ini anda bisa menggunakan semua fitur yang ada di Add-Ons Manager. Fitur baru seperti Plugins Manager atau penyempurnaan pada Add-Ons Installer bisa anda coba disini.</p><p>Update fitur ini adalah yang paling menonjol dan paling berpengaruh dalam update kali ini. Dengan sudah lengkapnya fitur pada Add-Ons Manager, diharapkan dapat mempermudah para developer khususnya untuk lebih mengembangkan Fiyo Add-Ons.</p><h3>Folder Admin Scure</h3><p>Anda pasti tahu jika FiyoCMS mendukung optimalisasi pengamanan folder admin. Dimana anda dapat mengganti nama folder admin sesuka anda. Tapi hal tersebut belum lengkap, karena masih harus dilakukan secara manual. Hal tersebut memang mudah dilakukan jika kita menjalankan FiyoCMS di server local (localhost), bagai mana jika di live server ? Pasti butuh proses yang panjang.</p><p>Kali ini anda dapat mengganti nama folder admin anda melalui menu Web Configuration pada menu Admin Panel. Lalu pilih bagian pojok kiri Konfigurasi Admin-Panel untuk mengganti nama folder admin dengan nama baru.</p><p><br></p>","2012-06-05 00:57:31","","0","","","","1","1","99","112","show_comment=1;\nshow_author=1;\nshow_date=1;\nshow_category=1;\nshow_tags=1;\nshow_hits=1;\nshow_rate=1;\nrate_value=27;\nrate_counter=3;\npanel_top=2;\npanel_bottom=2;\neditor_level=1;\nshow_title=2;\n","2014-10-11 12:11:09","5"),
("8","Membuat Template FiyoCMS","1","<p>Untuk memulai pembuatan tema perlu disiapkan file wajib dalam paket&nbsp;Fiyo Theme. File tersebut adalah sebagai berikut :</p>\n\n<ul>\n	<li>index.php</li>\n	<li>theme_details.php</li>\n	<li>theme_image.gif</li>\n	<li>spot_position.php (tambahan)</li>\n</ul>\n\n<h3>index.php</h3>\n\n<div style=\'page-break-after: always;\'><span style=\'display: none;\'>&nbsp;</span></div>\n\n<p><strong>index.php</strong> merupakan file utama untuk memuat seluruh file yang dibutuhkan. Untuk permulaan buat folder &#39;<strong>mytheme</strong>&#39; didalam folder root/themes/. Setelah itu buat file index.php dan sisipkan kode dibawah ini :</p>\n\n<pre class=\'brush:php\'>\n&lt;html&gt;\n    &lt;head&gt;&lt;title&gt;My Theme&lt;/title&gt;&lt;/head&gt;\n    &lt;body&gt;Text body&lt;/body&gt;\n&lt;/html&gt;</pre>\n\n<p>Setelah itu simpan dan set di Admin Panel untuk mengaktifkan mytheme sebagai tema utama. Apakah berhasil? Jika ya mungkin bisa kelangkah selanjutnya.</p>\n\n<p>Sekarang mulai untuk memuat system kedalam file tema. Sebelum itu kita perlu mengetahui fungsi dan konstanta yang bisa digunakan dalam membuat tema.</p>\n\n<ul>\n	<li><strong>FTitle </strong>: menampilkan judul situs sesuai format pada konfigurasi situs.</li>\n	<li><strong>FUrl </strong>: url utama atau url homepage.</li>\n	<li><strong>SiteName </strong>: nama situs.</li>\n	<li><strong>SiteTitle </strong>: judul situs.</li>\n	<li><strong>SiteLang </strong>: bahasa situs.</li>\n	<li><strong>MetaRobots </strong>: konfigurasi robots halaman.</li>\n	<li><strong>MetaDesc </strong>: deskripsi halaman.</li>\n	<li><strong>MetaKeys </strong>: katakunci halaman.</li>\n	<li><strong>FThemePath </strong>: direktori tema yang sedang digunakan.</li>\n	<li><strong>AdminPath </strong>: direktori tema AdminPanel.</li>\n	<li><strong>loadModule</strong>(&#39;posisi_modul&#39;) : memuat modul sesuai posisi dalam parameter.</li>\n	<li><strong>checkModule</strong>(&#39;posisi_modul&#39;) : digunakan apakah modul sesuai posisi parameter sedang aktif.</li>\n	<li><strong>loadApps</strong>() : memuat Apps.</li>\n	<li>\n	<div><strong><span style=\'line-height: 1.6em;\'>load</span></strong><span style=\'line-height: 1.6em;\'><strong>AppsCss</strong>() : fungsi untuk memuat seluruh css pada apps yang aktif.</span></div>\n	</li>\n	<li>\n	<div><strong><span style=\'line-height: 1.6em;\'>loadModuleCs</span></strong><span style=\'line-height: 1.6em;\'><strong>s</strong>() : fungsi untuk memuat seluruh module css yang aktif.</span></div>\n	</li>\n</ul>\n\n<p>Berikut adalah contoh potongan kode untuk bagian &lt;head&gt;.</p>\n\n<pre class=\'brush:php\'>\n&lt;!DOCTYPE html&gt;\n&lt;html lang=&quot;&lt;?php echo SiteLang; ?&gt;&quot;&gt;\n&lt;head&gt;\n    &lt;meta charset=&quot;utf-8&quot; /&gt;\n    &lt;title&gt;&lt;?php echo FTitle; ?&gt;&lt;/title&gt;\n    &lt;meta name=&quot;robots&quot; content=&quot;&lt;?php echo MetaRobots; ?&gt;&quot; /&gt;\n    &lt;meta name=&quot;keywords&quot; content=&quot;&lt;?php echo MetaKeys; ?&gt;&quot; /&gt;\n    &lt;meta name=&quot;description&quot; content=&quot;&lt;?php echo MetaDesc; ?&gt;&quot; /&gt;\n    &lt;meta name=&quot;generator&quot; content=&quot; Fiyo CMS Integrate Design Easily!&quot; /&gt;\n    &lt;?php loadAppsCss(); ?&gt;\n    &lt;?php loadModuleCss(); ?&gt;\n    &lt;link rel=&quot;shortcut icon&quot; type=&quot;image/x-icon&quot; href=&quot;&lt;?php echo FThemePath; ?&gt;/css/images/favicon.ico&quot; /&gt;\n    &lt;link rel=&quot;stylesheet&quot; href=&quot;&lt;?php echo FThemePath; ?&gt;/css/style.css&quot; type=&quot;text/css&quot; media=&quot;all&quot; /&gt;\n    &lt;script type=&quot;text/javascript&quot; src=&quot;&lt;?php echo FThemePath; ?&gt;/js/jquery-2.0.3.min.js&quot;&gt;&lt;/script&gt;\n&lt;/head&gt;</pre>\n\n<p>Pada potongan kode diatas hampir semua meta-tag sudah dipenuhi. fungsi loadCss(apps/modul) dimuat sebelum file css&nbsp;tema. Hal tersebut bertujuan agar css tema bisa mempengaruhi css modul/apps.&nbsp;</p>\n\n<p>Potongan kode diatas juga menunjukan bahwa terdapat folder css dan js yang menyimpan beberapa file pendukung. Disaranka untuk tidak memnuliskan javascript dalam mode inline atau langsung pada file index.php. Karena dapat merusak <em>module position</em>&nbsp;dari tema yang dibuat. pisahkan kedalam file tersendiri juga membuat struktur dan penulisan kode lebih rapi.</p>\n\n<p>Setelah bagian <em>head</em>&nbsp;selanjutnya bagian <em>body</em>. Perhatikan potongan kode berikut :</p>\n\n<pre class=\'brush:php\'>\n&lt;body&gt;\n   &lt;header id=&quot;header&quot;&gt;\n       &lt;div id=&quot;logo&quot;&gt;&lt;a href=&quot;&lt;?php echo FUrl; ?&gt;&quot;&gt;&lt;?php echo SiteName; ?&gt;&lt;/a&gt;\n       &lt;span&gt;&lt;?php echo SiteTitle; ?&gt;&lt;/span&gt;&lt;/div&gt;\n   &lt;/header&gt;\n   \n   &lt;nav id=&quot;navigation&quot;&gt;    \n      &lt;?php echo loadModule(&#39;mainmenu&#39;) ?&gt;\n   &lt;/nav&gt;\n   \n   &lt;div class=&quot;m-slider&quot;&gt;\n      &lt;?php loadModule(&#39;slide&#39;);?&gt;\n   &lt;/div&gt;        \n               \n   &lt;div class=&quot;main&quot;&gt;      \n&nbsp;      &lt;?php if(checkModule(&#39;right&#39;)) : ?&gt;  \n          &lt;div class=&quot;full&quot;&gt;\n&nbsp;            &lt;?php loadApps(); ?&gt;\n          &lt;/div&gt;\n&nbsp;      &lt;?php else : ?&gt;\n          &lt;div class=&#39;left&#39;&gt;\n&nbsp;            &lt;?php loadApps(); ?&gt;\n&nbsp;         &lt;/div&gt;\n&nbsp;         &lt;div class=&#39;right&#39;&gt;          \n             &lt;?php loadModule(&#39;right&#39;);?&gt;\n          &lt;/div&gt;\n&nbsp;      &lt;?php endif; ?&gt;\n   &lt;/div&gt;\n&lt;/body&gt;</pre>\n\n<p><span style=\'line-height: 1.6em;\'>Jika dilihat menurut potongan kode diatas terdapat posisi module mainmenu, slide dan right. Pada bagian konten akan tampil lebar jika module right tidak aktif. Dan akan dibagi menjadi dua bagian jika module right ada yang aktif sesuai kontrol checkModule().</span></p>\n\n<p>Setelah membuat file index.php secara lengkap sebenarnya sudah bisa digunakan secara utuh untuk Fiyo Theme. Namun, perlu theme_details.php sebagai informasi tema dan theme_image.gif sebagai gambar pendukung dari informasi tema.</p>\n\n<h3>theme_details.php</h3>\n\n<p>isi dan modifikasi bagian theme_details sesuai informasi tema yang diperlukan. Berikut contoh file theme_details.php.</p>\n\n<pre class=\'brush:php\'>\n$theme_name          =&#39;First Panel&#39;;\n$theme_version       =&#39;1.5.0&#39;;\n$theme_date          =&#39;17 August 2013&#39;;\n$theme_author        =&#39;Fiyo CMS&#39;;\n$theme_author_url    =&#39;http://portofolio.web.id&#39;;\n$theme_author_email  =&#39;firstryan@gmail.com&#39;;</pre>\n\n<h3>theme_image.gif</h3>\n\n<p>Buat screenshoot dari tema yang dibuat sebagai <em>thumbnail</em>&nbsp;(preview)&nbsp;tema. Rekomendasi berukuran 200x200 atau dengan ukuran yang presisi.</p>\n\n<h3>spot_position.php</h3>\n\n<p>Ini merupakan fitur dari Fiyo yaitu dapat memilih posisi modul dengan memilih dari preview tema. Pertama kita perlu menyiapkan terlebih dahulu gambar atau preview untuk&nbsp;spot_position. (misal spot_position.gif) Setelah itu gunakan dreamwaver untuk membuat imageMap sesuai modul yang dibuat.</p>\n\n<p>Hasil dari imageMap dari Dreamweaver contohnya seperti ini.</p>\n\n<pre class=\'brush:php\'>\n&lt;h3&gt;Fiyo Theme&lt;/h3&gt;\n&lt;img src=&quot;spot_position.gif&quot; width=&quot;600&quot; border=&quot;0&quot; usemap=&quot;#Map&quot; /&gt;\n&lt;map name=&quot;Map&quot; id=&quot;Map&quot;&gt;&lt;area  name=&quot;bottom-content&quot; shape=&quot;rect&quot; coords=&quot;66,80,379,171&quot; alt=&quot;slide&quot; /&gt;&lt;area  name=&quot;bottom-content&quot; shape=&quot;rect&quot; coords=&quot;279,183,379,229&quot; alt=&quot;top3&quot; /&gt;&lt;area  name=&quot;bottom-content&quot; shape=&quot;rect&quot; coords=&quot;173,183,270,230&quot; alt=&quot;top2&quot; /&gt;&lt;area  name=&quot;bottom-content&quot; shape=&quot;rect&quot; coords=&quot;68,183,164,229&quot; alt=&quot;top1&quot; /&gt;&lt;area  name=&quot;bottom-content&quot; shape=&quot;rect&quot; coords=&quot;66,447,380,480&quot; alt=&quot;bottom&quot; /&gt;\n  &lt;area shape=&quot;rect&quot; coords=&quot;65,485,532,501&quot; alt=&quot;breadchumb&quot; /&gt;\n  &lt;area shape=&quot;rect&quot; coords=&quot;392,78,536,468&quot; alt=&quot;right&quot; /&gt;\n  &lt;area shape=&quot;rect&quot; coords=&quot;391,9,532,29&quot; alt=&quot;search&quot; /&gt;\n  &lt;area shape=&quot;rect&quot; coords=&quot;67,43,537,67&quot; alt=&quot;mainmenu&quot;/&gt;\n&lt;/map&gt;</pre>\n\n<p>Setelah file utama dan file pendukung siap sekarang bisa terapkan tema yang sudah dibuat.</p>\n\n<h3>Membuat Paket Installer</h3>\n\n<p>Jika berniat untuk berbagi dari tema yang sudah dibuat anda perlu menyiapkan paket installer agar dapat diinstal melalui AddOns Installer.&nbsp;</p>\n\n<h3>installer.php</h3>\n\n<p>buat file installer.php satu folder dengan file index.php. Dan diingat bahwa file installer akan hilang otomatis jika paket Fiyo Theme berhasil diinstall. Berikut contoh file installer.php</p>\n\n<pre class=\'brush:php\'>\n$addons[&#39;name&#39;]   = &#39;My Theme&#39;;\n$addons[&#39;type&#39;]   = &#39;themes&#39;;\n$addons[&#39;folder&#39;] = &#39;mytheme&#39;;\n$addons[&#39;info&#39;]   = &#39;&lt;h1&gt;Ini tema buatan saya :)&lt;/h1&gt;&#39;;</pre>\n\n<p>Setelah file installer terbentuk pilih semua file yang ada pada folder tema yang dibuat lalu klik kanan dan pilih kompres sebagai zip.&nbsp;<span style=\'line-height: 1.6em;\'>Jadi sekarang selain terdapat file pendukung tema juga terdapat file .zip sebagai file installer yang telah dibuat.</span></p>\n","2012-01-03 11:37:11","","1","","","","1","1","99","252","show_comment=1;\nshow_author=1;\nshow_date=1;\nshow_category=1;\nshow_tags=1;\nshow_hits=1;\nshow_rate=1;\nrate_value=24;\nrate_counter=5;\npanel_top=2;\npanel_bottom=2;\neditor_level=3;\nshow_title=2;\n","2014-09-20 11:55:43","1"),
("10","Fiyo CMS 1.3.0","2","<p>Tanggal s 16 October 2012, Fiyo CMS versi 1.3.0 resmi di rilis dan pertama kalo di unggah pada situs www.sourceforge.net. Seperti apa yang telah di sampaikan sebelumnya pada artikel Pre-release Fiyo 1.3.0&nbsp;ada beberapa update yang tidak sedikit di tambahkan dalam versi ini. Disamping vitur yang telah di sampaikan pada Pre-release, ada beberapa fitur tambahan yang memang di tambahkan karena kebutuhan. Mau tau apa saja fitur lengkap yang ada di Fiyo CMS 1.3.0? Berikut data lengjap tetang apa saja yang ada pada Fiyo CMS 1.3.0.</p>\n\n<p>Pada versi anyar ini, developer mencoba untuk melengkapi fitur multi bahasa yang ada untuk AdminPanel, dan melengkapi beberapa <em>helper&nbsp;</em>agar memudahkan user dalam membuat website. Jadi apabila anda kesulitan, anda bias membuka<em> helper&nbsp;</em>yang tersedia pada setiap halaman AdminPanel.</p>\n\n<div style=\'page-break-after: always;\'><span style=\'display: none;\'>&nbsp;</span></div>\n\n<p>Ada fitur <em><strong>Auto Tagging</strong></em>, jadi kita bisa memberikan tag pada artikel dan akan otomatis erbentuk ketika kita menekan koma atau enter, sehingga diharapkan mampu mengurangi kesalahan pada penulisan tag artikel.</p>\n\n<p>Fitur yang <em><strong>Global Default Page</strong></em> juga merupakan fitur baru, disini kita dapat menentukan halaman default untuk semua halaman yang tidak mempunyai halaman tetap. Jadi, halaman yang tidak mempunyai Page_ID akan mempunyai halaman dengan&nbsp;<em><strong>Global Default Page.</strong></em></p>\n\n<p>Serta ada fitur&nbsp;RSS Feed yang bisa anda dapatkan pada kategori artikel atau tag artikel pada bagian bawah halaman dengan icon khusus. Untuk daftar update dengan tanda <strong>Ready!&nbsp;</strong>belum sepenuhnya di aktifkan, karena itu bermain dengan <em>.htaccess.&nbsp;</em>Disarankan untuk merubah&nbsp;<em>.htaccess</em> untuk live server saja dan bukan server lokal. Anda bisa mengaktifkanya dengan merubah isi dari&nbsp;<em>.htaccess.</em></p>\n\n<p>Berikut daftar update untuk Fiyo CMS 1.3.0 :</p>\n\n<ul>\n	<li>Auto Generate Meta Description</li>\n	<li>Auto Generate Meta Keyword</li>\n	<li>Auto Generate Meta Robots</li>\n	<li>Auto Generate Meta Author</li>\n	<li>Optimize Page Title</li>\n	<li>GZiP <strong>Ready!</strong></li>\n	<li>SpeedUp Caching Server &amp; Browser <strong>Ready!</strong></li>\n	<li>Copressed Static File <strong>Ready!</strong></li>\n	<li>Scurity libwww (Library World Wide Web) via .httaccess<strong> Ready!</strong></li>\n	<li>RSS Feed</li>\n	<li>Auto Tagging</li>\n	<li>Default Global Page</li>\n</ul>\n\n<p>Fix Bug :</p>\n\n<ul>\n	<li>Scurity Media Manager</li>\n	<li>Auto Change AdminPanel</li>\n	<li>Auto Installer in LocalServer</li>\n	<li>MultiDeletation on Admin Panel</li>\n</ul>\n\n<p>Change Log :</p>\n\n<ul>\n	<li>Add new<em> data</em> for table <strong><em>_setting :</em></strong>\n\n	<ul>\n		<li>lang =&gt; language</li>\n		<li>backend_folder =&gt; Auto change AdminPanel</li>\n		<li>follow_link = Meta Robots</li>\n		<li>site_mail = Official Site Mail</li>\n	</ul>\n	</li>\n	<li>Add new <em>column</em>&nbsp;for table&nbsp;<strong><em>_article_category :</em></strong>\n	<ul>\n		<li>keyword =&gt; Meta Keyword category</li>\n	</ul>\n	</li>\n	<li>Add new&nbsp;<em>column</em>&nbsp;for table&nbsp;<strong><em>_menu :</em></strong>\n	<ul>\n		<li>global =&gt; Global default Page</li>\n	</ul>\n	</li>\n</ul>\n","2013-01-09 14:20:50","","0","","","","1","1","99","486","show_comment=1;\nshow_author=1;\nshow_date=1;\nshow_category=1;\nshow_tags=1;\nshow_hits=1;\nshow_rate=1;\nrate_value=24;\nrate_counter=6;\npanel_top=0;\npanel_bottom=1;\neditor_level=3;\nshow_title=2;\n","2014-10-11 13:06:07","5"),
("12","Mengenal Lebih Dekat tentang Fiyo CMS","1","<p>Bagi yang masih penasaran dan bertanya-tanya apa itu Fiyo CMS? Buat apa sih Fiyo CMS? Atau, apalagi nih Fiyo CMS? Jangan jangan itu virus? Wah kagak minat ah!</p><p>Tenang, tenang sabar dulu, langsung saja nih silahkan dibaca untuk lebih jelasnya.</p><div style=\'page-break-after: always;\' contenteditable=\'false\' class=\'cke_pagebreak\' data-cke-display-name=\'pagebreak\' aria-label=\'Page Break\' title=\'Page Break\'></div><p>Fiyo CMS adalah sebuah Content Management System.</p><blockquote><p>Apalagi nih Content Management System ?</p></blockquote><p>Content Management System atau dalam bahasa Indonesia disebut Sistem Manajemen Konten (disingkat CMS), adalah software yang memungkinkan seseorang untuk menambahkan dan/atau memanipulasi (mengubah) isi dari suatu situs Web.<em style=\'&amp;quote;font-size:\'>&nbsp;(<a data-cke-saved-href=\'http://id.wikipedia.org/wiki/Sistem_manajemen_konten\' href=\'http://id.wikipedia.org/wiki/Sistem_manajemen_konten\'>http://id.wikipedia.org/wiki/Sistem_manajemen_konten</a>)</em></p><p>Contoh lain CMS seperti Joomla, Wrodpress, bahkan Blogspot juga CMS looh. Gimana sudah bisa mengertikan apa itu CMS?</p><blockquote><p>Jadi sama aja antara Fiyo dengan CMS yang lain ?</p></blockquote><p>Ehmm, kalo dibilang sama sih iya, kan jenisanya juga sama-sama CMS. Tetapi Fiyo CMS juga pasti ada bedanya, apalagi dengan CMS yang sudah memiliki banyak developer (pengembang) seperti Joomla, Wrodpress, Drupal, dll.</p><p>Tapi tenang saja, Fiyo CMS mempunyai fitur yang gak kalah canggihnya. dari mulai kemudahan membuat sebuah theme atau convert template gratisan ke Fiyo Theme dengan cara yang mudah.</p><p>Ditambah lagi, developernya orang Indonesia yang ramah-ramah, jadi bisa mudah tanya jawab dengan mereka.</p><blockquote><p>Fiyo CMS free kan ?</p></blockquote><p>Oh, tentunya <em>free</em>! Karena disesuaikan dengan selera orang Indonesia, hahaha.</p><p>Fiyo CMS juga boleh di <em>otak-atik&nbsp;</em>sesuai kebutuhan, tetapi jangan merubah nama Fiyo CMS dengan nama baru lho! Sangat dilarang dan tidak bijak. Alangkah baiknya jika kita saling menghargai karya orang lain.</p><p>Yang terpenting adalah, kata free yang bararti bebas dan gratjs itu berbeda. Fiyo CMS adalah software free dalam arti <u>bebas</u>.</p><blockquote><p>Lisensinya gimana untuk Fiyo CMS ?</p></blockquote><p>Fiyo CMS menggunakan License&nbsp;GNU General Public License, version 3 (GPL-3.0) sebagai basis lisensinya.</p><p>Jadi menurut keterangan untuk lisensi tersebut, adalah setiap orang dapat mengopy (mengunduh) dan mendisitribusikan kembali. Tetapi tidak diperbolehkan untuk melakukan perubahan terhadap sistem yang ada tanpa izin.</p><blockquote><p>Emang Fiyo CMS bisa dipake buat apa aja sih ?</p></blockquote><p>Fiyo CMS sengaja disiapkan untuk pengembangan yang lebih lanjut, meski dasarnya adalah CMS yang simple. Dari kategori yang umum digunakan oleh orang-orang, yaitu digunakan untuk <em>ngeblog</em>, buat toko online, website perkantoran, &nbsp;website pemerintahan, dan masih banyak lagi sesuai keinginan anda.</p><p>Fiyo CMS yang berbasis Fiyo Framework juga telah dikembangkan untuk pembuatan sistem informasi berbasis website, seperti Sistem Administrasi Sekolah, Sistem Perkantoran, Sistem Keuangan, dan Sistem Database lainya.</p><p>Jadi, meski simple pengembangan Fiyo CMS masihlah panjang karena akan ada banyak penambahan AddOns seiring berjalanya waktu.&nbsp;</p><blockquote><p>Wah jadi gak sabar pingin coba nih :)</p></blockquote><p>Waaaah, udah pingin nyobai nih? Langsung aja download Fiyo CMS versi terbaru.</p><p>Sekian dulu ya artikel kali ini, semoga dapat menambah wawasan para pembaca.</p><p><em>Dukung terus buatab Asli 100% Indonesia !</em></p>","2012-05-01 22:35:31","","1","","","","1","1","99","1145","show_comment=1;\nshow_author=1;\nshow_date=1;\nshow_category=1;\nshow_tags=1;\nshow_hits=1;\nshow_rate=1;\nrate_value=34;\nrate_counter=7;\npanel_top=2;\npanel_bottom=1;\neditor_level=1;\nshow_title=2;\n","2014-10-11 12:43:54","1"),
("14","Fiyo CMS 1.5.0","1","<p>Semakin optimal peforma dari Fiyo CMS di versi 1.5.0 ini. Banyak perubahan dari sisi <em>system core</em> yang ada untuk mengoptimalkan Fiyo CMS. Kami ingin selalu menyajikan sebuah perangkat yang mudah digunakan, sangat mudah dan ringan diakses. Oleh karena itu kami akan terus melekukan perbaikan dan invoasi serta menerima saran dari para pengguna Fiyo CMS.</p>\n\n<p>Merupakan penyempurnaan dari versi sebelumnya, yaitu Fiyo 1.4.0 dengan penambahan fitur yang banyak, Fiyo 1.5.0 lebih spesifik kepada penyempurnaan dari awal Fiyo CMS terbentuh hingga versi yang sekarang. Fungsi dari AdminPanel dan situs depan telah aktif secara keseluruhan.</p>\n\n<hr id=\'system-readmore\' />\n<h2>Edit Theme</h2>\n\n<p>Fiyo 1.5.0 memiliki fitur baru dibagian <strong>Theme Manager</strong>, yaitu penambahan tombol <u>Edit Theme</u>. Dimana kita bisa mengedit file yang ada dalam <em>theme</em> yang dipilih.</p>\n\n<p style=\'text-align: center;\'><img alt=\'Edit Theme\' src=\'/media/images/edit_theme.jpg\' style=\'width: 464px; height: 298px;\' /></p>\n\n<p>Anda hanya perlu memilih file yang ingin di edit dan simpan dengan dengan mudah disisi kanan layar.</p>\n\n<p style=\'text-align: center;\'><img alt=\'Edit File Theme on Fiyo CMS\' src=\'/media/images/file_theme.gif\' style=\'width: 600px; height: 323px;\' /></p>\n\n<p>Dengan ini kita dengan mudah menambahkan tag custom apapun, seperti Google Analytics, file css, file javascript atau tag lainya.&nbsp;</p>\n\n<h2>HTML Valid Ready!</h2>\n\n<p>Memang semua bisa mengatakan bahwa mereka juga siap untuk menjadikan situs lulus uji validasi HTML. <u>Tetapi kami jauh lebih siap</u>&nbsp;Fiyo 1.5.0 akan membantu Anda untuk memuat semua file css didalam tag &lt;head&gt;. tinggal tambahkan kode berikut di setiap file tema yang digunakan,</p>\n\n<div><span style=\'font-family:courier new,courier,monospace;\'>&lt;?php loadAppsCss(); ?&gt;</span></div>\n\n<div><span style=\'font-family:courier new,courier,monospace;\'>&lt;?php loadModuleCss(); ?&gt;</span></div>\n\n<div>&nbsp;</div>\n\n<h2 style=\'text-align: center;\'><em>Fiyo 1.5.0, More Stable, More Fast and More Elegant</em></h2>\n","2013-08-01 21:26:08","","0","","","","1","1","99","674","show_comment=2;\nshow_author=2;\nshow_date=2;\nshow_category=2;\nshow_tags=2;\nshow_hits=2;\nshow_rate=2;\nrate_value=10;\nrate_counter=2;\npanel_top=2;\npanel_bottom=2;\neditor_level=3;\nshow_title=2;\n","2014-10-11 13:06:24","5"),
("195","Program Studi ABC DEFG ini adalah asdas dasd asd asdas das asd asd asd asd as","1","<p>jjj</p>\n","2014-10-02 13:51:31","","0","","","","1","1","99","9","show_comment=2;\nshow_author=2;\nshow_date=2;\nshow_category=2;\nshow_tags=2;\nshow_hits=2;\nshow_rate=2;\nrate_value=0;\nrate_counter=0;\npanel_top=2;\npanel_bottom=2;\neditor_level=3;\nshow_title=2;\n","2014-10-11 13:04:01","5"),
("175","Fiyo CMS 1.4.0","1","<p>Setelah melalui masa percobaan untuk berbagai situs yang telah kembangkan, maka Fiyo 1.4.0 resmi dirilis pa;da tanggal 4 April 2013. Dengan mengusung judul <strong>Fiyo Go Store!&nbsp;</strong>dan pastinya Fi Store pun menjadi senjata andalan.6</p>\n\n<p>Fersi baru ini memiliki perbedaan dan perkembangan yang cukup signifikan. Karena update kali ini tidak hanya memperbaiki tetapi juga menambah beberapa modul dan apps baru, serta memodifikasi dasboard AdminPanel agar lebih informatif.</p>\n\n<div style=\'page-break-after: always;\'><span style=\'display: none;\'>&nbsp;</span></div>\n\n<p>Kita akan bahas satu-persatu mulai dari (belakang (AdminPanel)&nbsp;hingga sisi depan (Front Site).</p>\n\n<h3>Dasboard AdminPanel</h3>\n\n<p>Pada saat pertama kali login pada AdminPanel pasti akan diarahkan ke halaman Dasboard. Kali ini dasboard akan sedikit dirubah layoutnya dan penambahan fitur statistik agar AdminPanel lebih informatif.</p>\n\n<p>Berikut preview tampilan dasboard AdminPanel.</p>\n\n<p><img alt=\'Dasboard Fiyo CMS\' longdesc=\'Dasboard Fiyo CMS\' src=\'/media/images/dasboard.jpg\' style=\'width: 630px; height: 368px;\' /></p>\n\n<p>Gambar diatas pada sisi kiri menujukan statistik artikel terbaru dari semenjak Anda login terakhir kali di AdminPanel, komentar yang belum disetujui, jumlah user baru, dan versi Fiyo yang digunakan.</p>\n\n<p>Serta pada sisi kiri ada <em>line-chart</em>&nbsp;yang menunjukan jumlah pengunjung perhari dalam 7 hari terakhir. data pada warna biru menunjukan pengunjung unik untuk setiap <em>session</em>-nya dan untuk warna merah adalah pengujung unik setiap IP yang berbeda.</p>\n\n<p>Juga perombakan <em>shortcut icon</em> agar lebih fokus dikiri dan lebih rapih.</p>\n\n<h3>Fiyo Installer</h3>\n\n<p>Pada Fiyo 1.4.0 untuk installernya dibaerikan popup informasi tambahan sebagai panduan instalasi.</p>\n\n<p>Apakah itu server lokal yang tidak harus membuat database atau user terlebih daulu. Ataukan di server hosting yang mengharuskan untuk membuat user atau database terlebih dahulu.</p>\n\n<h3>Article System</h3>\n\n<p>Ada fitur baru yang mungkin wajib diketahui di bagian artikel. Pada bagian editor terdapat tombol baru di samping tombol &#39;Read More&#39;, yaitu tombol &#39;Attach File&#39; yang berguna untuk memanggil file yang disimpan di Media Manager. Tombol ini biasa digunakan untuk menautkan file yang siap diunduh oleh pengujung situs.</p>\n\n<p>Juga adanya pengaturan penanggalan yang berfungsi untuk mengatur penjadwalan artikel. Jadi, apabila artikel belum memasuki tanggal yang telah ditetapkan, maka artikel belom muncul atau bisa dikatakan belum aktif. Hal ini juga akan merubah input tanggal menjadi (Y-M-d H:i:s).</p>\n\n<p>Dan pengembangan baru untuk artikel adalah, penataan layout. Anda bisa memilih model layout melalui Menu, lalu seting parameter sesuai keinginan. Berikut gambaran layout urut mulai dari default, blog dan list.</p>\n\n<p>&nbsp;</p>\n\n<h3>User Management</h3>\n\n<p>Pada bagiang User Managemement juga ditambahkan fungsi baru untuk mengatur apakah situs menerima pendaftaran baru dari pengunjung atau tidak.&nbsp;</p>\n\n<p>Anda bisa menemukan tombol setting pada bagian atas di samping tombol simpan, hapus dan bantuan.</p>\n\n<h3>Comment System</h3>\n\n<p>Sistem komentar yang menggunakan Fi Comment juga turut diperbaharui. Anda bisa menggunakan dua pilihan <em>security code</em>&nbsp;atau yang lebih dikenal dengan <strong>captcha</strong>.&nbsp;</p>\n\n<p>Pada bagian konfigurasi komentar terdapat dua kolom untuk menampilkan reCaptcha. Apabila kolom tersebut salah atau tidak diisi maka Fi Comment akan menggunakan captcha matematika.</p>\n\n<p>Capthca matematika sendiri juga sudah diperbaharui, tidak lagi bersifat teks dan sekarang berbantuk gambar. Alasan memilih captcha matematika adalah untuk mengasah otak agar lebih aktif lagi dengan hitungan-hitungan sederhana.</p>\n\n<h3>Statistic System</h3>\n\n<p>Ada plugin baru yang ditanamkan didalam Fiyo 1.4.0 ini, yaitu sistem statistik untuk melihat detil pengujung. Sistem ini bekerja apabila ada yang mengakses website dan langsung akan tercatat IP, waktu, user id, platform, browser, negara dan kota yang tersimpan ditabel<em> _statistic</em></p>\n\n<p>Tabel tersebut bisa dimanfaatkan untuk membuat sebuah AddOn baru. Contoh AddOn dari pengembangan tabel tersebut adalah, statistik pengunjung di AdminPanel dan modul Ststistik yang menggantikan <em>Fi Tracker</em>.</p>\n\n<h3>Fiyo Store</h3>\n\n<p>Kali ini AddOn yang banyak ditunggu-tunggu adalah Fiyo Store atau dikenal dengan <strong>Fi Store</strong>. Tetapi Fi Store tidak disertakan secara langsung dalam paket instalasi versi terbaru ini. Anda harus megunduhnya dihalaman AddOns.</p>\n\n<p>Rilis untuk Fi Store waktunya sendiri tidak bersamaan dengan rislis Fiyo 1.4.0, karena senagja dijedakan beberapa hari untuk mengantisipasi update kecil pada Fiyo 1.4.0.</p>\n\n<h3>Sitemap XML Generator</h3>\n\n<p>Anda bisa melakukan pelacakan setiap url yang diciptakan dan merangkumnya dalam satu file XML yang bisa digunakan sebagai Sitemap. Fitur ini bisa digunakan dengan menggunakan <strong>Fi Sitemap</strong>.&nbsp;</p>\n\n<h3>Change Logs</h3>\n\n<ol>\n	<li>Penambahan fitur Sitemap &quot;XML&quot;.</li>\n	<li>Penambahan fitur perijinan regristrasi user baru.</li>\n	<li>Penambahan fitur reCaptcha dan captcha math.</li>\n	<li>Penambahan sistem rating untuk Article.</li>\n	<li>Penambahan biodata <em>Author</em> artikel (user).</li>\n	<li>Penambahan konfigurasi rating pada Article Parameter.</li>\n	<li>Penambahan konfigurasi layout artikel.</li>\n	<li>Penambahan fitur statistik.</li>\n	<li>Mengganti sistem penganggalan pada <em>Article</em>.</li>\n	<li>Mengganti nama fungsi&nbsp;<strong>dataConfig</strong>&nbsp;menjadi&nbsp;<strong>siteConfig</strong>.</li>\n	<li>Perbaikan fitur <strong>XML</strong> generat untuk <strong>RSS Feed.</strong></li>\n	<li>Perbaikan sistem Auto Installer.</li>\n</ol>\n","2013-03-01 01:42:46","","1","","Teknologi,CMS","","1","1","99","34051","show_comment=2;\nshow_author=2;\nshow_date=2;\nshow_category=0;\nshow_tags=1;\nshow_hits=1;\nshow_rate=1;\nrate_value=10;\nrate_counter=2;\npanel_top=2;\npanel_bottom=2;\neditor_level=1;\nshow_title=2;\n","2014-10-11 13:06:09","1");

--

DROP TABLE IF EXISTS `db_prefix_article_category`;

--

CREATE TABLE `db_prefix_article_category` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `parent_id` int(5) NOT NULL,
  `description` varchar(250) NOT NULL,
  `keywords` varchar(150) NOT NULL,
  `level` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=latin1;

--

INSERT INTO `db_prefix_article_category` (`id`,`name`,`parent_id`,`description`,`keywords`,`level`) VALUES ("1","Blog","0","Blog","Blog","99"),
("2","News","0","Berita Mengenai Kampus","Berita kampus","99"),
("3","Page","0","","","99"),
("55","Tutorial","0","","","99");

--

DROP TABLE IF EXISTS `db_prefix_article_tags`;

--

CREATE TABLE `db_prefix_article_tags` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(200) NOT NULL,
  `hits` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=79 DEFAULT CHARSET=latin1;

--

INSERT INTO `db_prefix_article_tags` (`id`,`name`,`description`,`hits`) VALUES ("49","Teknologi","","0"),
("50","House","","0"),
("76","CMS","","0"),
("77","Android","","0");

--

DROP TABLE IF EXISTS `db_prefix_comment`;

--

CREATE TABLE `db_prefix_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `link` varchar(250) NOT NULL,
  `user_id` int(5) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `website` varchar(100) NOT NULL,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `comment` text NOT NULL,
  `status` int(1) NOT NULL,
  `apps` varchar(50) NOT NULL,
  `parent_id` int(10) NOT NULL,
  `parent_user_email` varchar(50) NOT NULL,
  `thread_user_email` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=136 DEFAULT CHARSET=latin1;

--

INSERT INTO `db_prefix_comment` (`id`,`link`,`user_id`,`name`,`email`,`website`,`date`,`comment`,`status`,`apps`,`parent_id`,`parent_user_email`,`thread_user_email`) VALUES ("134","?app=article&view=item&id=14","0","Seem","seem@gmail.com","","2014-09-02 18:00:38","Semoga tambah jaya selalu min","1","article","1","1","1"),
("135","?app=article&view=item&id=12","1","Administrator","admin@admin.com","","2014-09-02 18:04:19","Benar juga gan!","1","article","1","1","1");

--

DROP TABLE IF EXISTS `db_prefix_comment_setting`;

--

CREATE TABLE `db_prefix_comment_setting` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `value` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--

INSERT INTO `db_prefix_comment_setting` (`id`,`name`,`value`) VALUES ("1","auto_submit","0"),
("2","name_filter","Admin, Administrator"),
("3","email_filter","email"),
("4","word_filter","anj, ngsat, sial, njin"),
("6","recaptcha_privatekey",""),
("5","recaptcha_publickey","");

--

DROP TABLE IF EXISTS `db_prefix_contact`;

--

CREATE TABLE `db_prefix_contact` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `gender` tinyint(1) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(20) NOT NULL,
  `country` varchar(20) NOT NULL,
  `zip` varchar(10) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `fax` varchar(20) NOT NULL,
  `job` varchar(100) NOT NULL,
  `photo` text NOT NULL,
  `web` varchar(30) NOT NULL,
  `ym` varchar(50) NOT NULL,
  `fb` varchar(50) NOT NULL,
  `tw` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `group_id` int(5) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--

INSERT INTO `db_prefix_contact` (`id`,`name`,`gender`,`email`,`address`,`city`,`state`,`country`,`zip`,`phone`,`fax`,`job`,`photo`,`web`,`ym`,`fb`,`tw`,`description`,`group_id`,`status`) VALUES ("1","First Ryan","1","firstryan@gmail.com","Jl. Selomulyo Mukti Timur VI\n\n\n\n444","Semarang","Jawa Tengah","Indonesia","50195","+62 898 578 578 7","","","/fiyo/media/images/brush.png","firstryan.net","firstryan@ymail.com","firstryan","firstryan","","1","1");

--

DROP TABLE IF EXISTS `db_prefix_contact_group`;

--

CREATE TABLE `db_prefix_contact_group` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--

INSERT INTO `db_prefix_contact_group` (`id`,`name`,`description`) VALUES ("1","Developer","Fiyo Developers ");

--

DROP TABLE IF EXISTS `db_prefix_gallery_album`;

--

CREATE TABLE `db_prefix_gallery_album` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `parent_id` int(5) NOT NULL,
  `cover` varchar(250) NOT NULL,
  `description` varchar(250) NOT NULL,
  `keywords` varchar(150) NOT NULL,
  `level` int(5) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--

INSERT INTO `db_prefix_gallery_album` (`id`,`name`,`parent_id`,`cover`,`description`,`keywords`,`level`,`status`) VALUES ("12","Administrator","0","/fiyo/media/images/dasboard.jpg","","","99","1");

--

DROP TABLE IF EXISTS `db_prefix_gallery_config`;

--

CREATE TABLE `db_prefix_gallery_config` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `value` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--

INSERT INTO `db_prefix_gallery_config` (`id`,`name`,`value`) VALUES 
--

DROP TABLE IF EXISTS `db_prefix_gallery_photo`;

--

CREATE TABLE `db_prefix_gallery_photo` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `category` int(5) NOT NULL,
  `photo` text NOT NULL,
  `date` datetime NOT NULL,
  `author` varchar(250) NOT NULL,
  `author_id` int(5) NOT NULL,
  `description` text NOT NULL,
  `tag` text NOT NULL,
  `featured` int(1) NOT NULL,
  `status` int(1) NOT NULL,
  `level` int(1) NOT NULL,
  `hits` int(10) NOT NULL,
  `parameter` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--

INSERT INTO `db_prefix_gallery_photo` (`id`,`title`,`category`,`photo`,`date`,`author`,`author_id`,`description`,`tag`,`featured`,`status`,`level`,`hits`,`parameter`) VALUES ("16","DJ Equipment Rental","12","/fiyo/media/images/dasboard.jpg","2014-10-01 01:09:00","","5","","","1","1","99","26","rate_value=5;\nrate_counter=2;\nrate_value=10;\n"),
("17","DJ Equipment Rental","12","/fiyo/media/images/login-default.jpg","2014-10-01 03:06:45","","5","","","1","1","99","19","rate_value=10;\nrate_counter=3;\nrate_value=10;\n"),
("18","Lumidians","12","/fiyo/media/images/10644100_839590032718190_8706335075921275267_o.jpg","2014-10-02 13:54:35","","5","","","1","1","99","37","rate_value=18;\nrate_counter=4;\n");

--

DROP TABLE IF EXISTS `db_prefix_menu`;

--

CREATE TABLE `db_prefix_menu` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `category` varchar(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `link` text NOT NULL,
  `app` varchar(100) NOT NULL,
  `parent_id` int(5) NOT NULL,
  `status` int(5) NOT NULL,
  `short` int(5) NOT NULL,
  `level` int(5) NOT NULL DEFAULT '3',
  `home` int(5) NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL,
  `show_title` int(2) NOT NULL,
  `sub_name` varchar(100) NOT NULL,
  `class` varchar(200) NOT NULL,
  `style` text NOT NULL,
  `parameter` text NOT NULL,
  `global` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=141 DEFAULT CHARSET=latin1;

--

INSERT INTO `db_prefix_menu` (`id`,`category`,`name`,`link`,`app`,`parent_id`,`status`,`short`,`level`,`home`,`title`,`show_title`,`sub_name`,`class`,`style`,`parameter`,`global`) VALUES ("2","mainmenu","About","?app=article&view=item&id=12","app_article","0","1","3","99","0","","0","","","","per_page=5;\nshow_panel=0;\nread_more=;\nimgW=120;\nimgH=100;\nformat=default;\nintro=5;\npanel_format=how_panel=0;\nshow_rss=1;\n","0"),
("3","mainmenu","Blog","?app=article&view=category&id=1","app_article","0","1","2","99","0","","0","","","","per_page=6;\nshow_panel=1;\nread_more=;\nimgW=120;\nimgH=100;\nformat=grid;\nintro=5;\npanel_format=;\nshow_rss=1;\n","0"),
("8","mainmenu","Contact","?app=contact&view=group&id=1","app_contact","0","1","5","99","0","","1","","","","per_page=10;\nshow_name=1;\nshow_group=1;\nshow_gender=0;\nshow_address=0;\nshow_phone=0;\nshow_email=0;\nshow_links=0;\nshow_job=0;\nshow_photo=0;\n","0"),
("23","mainmenu","Home","?app=article&view=archives","app_article","0","1","0","99","1","","1","","","","per_page=6;\nshow_panel=1;\nread_more=;\nimgW=200;\nimgH=150;\nformat=grid;\nintro=4;\npanel_format=;\nshow_rss=1;\n","1"),
("41","mainmenu","Sub Child","?app=article&view=category&id=1","app_article","103","1","0","99","0","","1","","","","per_page=5;\nshow_panel=0;\nread_more=;\nimgW=120;\nimgH=100;\nformat=default;\nintro=5;\npanel_format=;\nshow_rss=0;\n","0"),
("18","mainmenu","Category","?app=article&view=item&id=10","app_article","0","1","1","99","0","","0","","","","per_page=5;\nshow_panel=0;\nread_more=;\nimgW=120;\nimgH=100;\nformat=default;\nintro=5;\npanel_format=;\nshow_rss=0;\n","0"),
("42","footer","First Ryan","?app=article&view=item&id=5","app_article","0","0","0","99","0","","1","","","","per_page=5;\nshow_panel=0;\nread_more=;\nimgW=120;\nimgH=100;\nformat=default;\nintro=5;\npanel_format=;\nshow_rss=0;\n","0"),
("108","footer","asd","?app=article&view=featured","app_article","0","1","0","99","0","","1","","","","","0"),
("55","adminpanel","Dashboard","index.php","link","0","1","0","3","0","","1","","icon-home","","","0"),
("56","adminpanel","Articles","#","sperator","0","1","1","5","0","","1","article","icon-file-text","","","0"),
("57","adminpanel","New Article","?app=article&act=add","link","56","1","0","3","0","","1","","icon-plus","","","0"),
("63","adminpanel","Comments","?app=article&view=comment","link","56","1","3","3","0","","1","","icon-comments","","","0"),
("61","adminpanel","Article List","?app=article","link","56","1","1","99","0","","1","","icon-list-alt","","","0"),
("62","adminpanel","Categories","?app=article&view=category","link","56","1","2","2","0","","1","","icon-book","","","0"),
("64","adminpanel","Tags","?app=article&view=tag","link","56","1","4","3","0","","1","","icon-tag","","","0"),
("65","adminpanel","Apps","#","sperator","0","1","2","3","0","","1","apps","icon-star","","","0"),
("66","adminpanel","File Manager","#","sperator","0","1","5","99","0","","1","media","icon-folder-open","","","0"),
("67","adminpanel","Images","?app=media","link","66","1","1","5","0","","1","","icon-picture","","","0"),
("68","adminpanel","Videos","?app=media&type=flash","link","66","1","1","5","0","","1","","icon-facetime-video","","","0"),
("87","adminpanel","Backup & Restore","?app=config&view=backup","link","83","1","3","1","0","","1","","icon-repeat","","","0"),
("69","adminpanel","Other Files","?app=media&type=files","link","66","1","2","5","0","","1","","icon-file","","","0"),
("70","adminpanel","Menus","#","sperator","0","1","6","2","0","","1","menu","icon-list-ul","","","0"),
("71","adminpanel","New Menu","?app=menu&view=add","link","70","1","0","2","0","","1","","icon-plus","","","0"),
("72","adminpanel","Menu List","?app=menu","link","70","0","1","2","0","","1","","icon-list-alt","","","0"),
("73","adminpanel","Categories","?app=menu&view=category","link","70","1","2","2","0","","1","","icon-book","","","0"),
("74","adminpanel","Modules","?app=module","link","0","1","7","2","0","","1","module","icon-inbox","","","0"),
("75","adminpanel","Themes","#","sperator","0","1","8","2","0","","1","theme","icon-magic","","","0"),
("76","adminpanel","Front End","?app=theme","link","75","1","0","2","0","","1","","icon-desktop","","","0"),
("77","adminpanel","Admin Panel","?app=theme&view=admin","link","75","1","2","2","0","","1","","icon-laptop","","","0"),
("78","adminpanel","Users","#","sperator","0","1","9","2","0","","1","user","icon-user","","","0"),
("79","adminpanel","New User","?app=user&act=add","link","78","1","0","2","0","","1","","icon-plus","","","0"),
("80","adminpanel","User List","?app=user","link","78","1","2","2","0","","1","","icon-list-alt","","","0"),
("81","adminpanel","User Group","?app=user&view=group","link","78","1","3","2","0","","1","","icon-group","","","0"),
("82","adminpanel","Plugins","?app=plugin","link","0","1","10","2","0","","1","plugin","icon-bolt","","","0"),
("83","adminpanel","Settings","#","sperator","0","1","11","2","0","","1","config","icon-cog","","","0"),
("84","adminpanel","Configuration","?app=config","link","83","1","0","2","0","","1","","icon-cogs","","","0"),
("85","adminpanel","Manages","?app=config&view=apps","link","83","1","2","1","0","","1","","icon-th","","","0"),
("86","adminpanel","Install & Update","?app=config&view=install","link","83","1","3","1","0","","1","","icon-download-alt","","","0"),
("89","adminpanel","Sitemap","?app=sitemap","link","65","1","20","2","0","","1","","icon-sitemap","","","0"),
("90","adminpanel","Permalink","?app=permalink","link","65","1","0","2","0","","1","","icon-link","","","0"),
("92","adminpanel","Contact","?app=contact","link","65","1","0","99","0","","1","","icon-group","ooo","","0"),
("103","mainmenu","Child Menu","#","sperator","18","1","0","99","0","","1","","","","","0"),
("105","mainmenu","Very Child","#","sperator","41","1","0","99","0","","1","","","","","0"),
("107","footer","Contact","?app=article&view=featured","app_article","42","1","0","99","0","","1","","","","per_page=5;\nshow_panel=0;\nread_more=;\nimgW=120;\nimgH=100;\nformat=default;\nintro=5;\npanel_format=;\nshow_rss=0;\n","0"),
("110","mainmenu","Gallery","?app=gallery&view=default","app_gallery","0","1","0","99","0","","1","","","","per_page=5;\nshow_panel=0;\nread_more=;\nimgW=120;\nimgH=100;\nformat=;\nintro=0;\npanel_format=;\nshow_rss=0;\n","0"),
("140","adminpanel","Gallery","?app=gallery","app_gallery","65","1","0","3","0","","1","gallery","icon-camera","","","0");

--

DROP TABLE IF EXISTS `db_prefix_menu_category`;

--

CREATE TABLE `db_prefix_menu_category` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(200) NOT NULL,
  `level` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_2` (`category`),
  UNIQUE KEY `category_3` (`category`),
  KEY `category` (`category`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

--

INSERT INTO `db_prefix_menu_category` (`id`,`category`,`title`,`description`,`level`) VALUES ("1","mainmenu","Main Menu","Menu utama","2"),
("2","footer","Footer Menu","","99"),
("9","adminpanel","Admin Panel","Menu for Admin Panel","1");

--

DROP TABLE IF EXISTS `db_prefix_module`;

--

CREATE TABLE `db_prefix_module` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `folder` varchar(150) NOT NULL,
  `position` varchar(100) NOT NULL,
  `short` int(2) NOT NULL,
  `level` int(2) NOT NULL DEFAULT '3',
  `status` int(2) NOT NULL DEFAULT '1',
  `page` varchar(250) NOT NULL,
  `parameter` text NOT NULL,
  `class` varchar(200) NOT NULL,
  `style` text NOT NULL,
  `show_title` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=123 DEFAULT CHARSET=latin1;

--

INSERT INTO `db_prefix_module` (`id`,`name`,`folder`,`position`,`short`,`level`,`status`,`page`,`parameter`,`class`,`style`,`show_title`) VALUES ("1","Menu","mod_menu","mainmenu","0","99","1","23,110,18,41,3,2,8,42","category=mainmenu;\ntype=2;\nsub_menu=1;\nsub_title=0;\n","","","0"),
("121","Tags","mod_article_tags","right","2","99","0","23,18,103,41,3,2,8,42,104","","","","1"),
("118","Search","mod_search","search","0","99","0","23,18,41,3,2,8,42","","","","0"),
("5","You are here : ","mod_breadcrumb","top1","0","99","1","23,18,41,3,2,8,42","","","","0"),
("6","Comments","mod_comment","right","2","99","0","23,18,41,3,2,8,42","name=1;\ngravatar=1;\ntitle=1;\ncomment=0;\ndate=1;\ntext=100;\nitem=5;\n","","","1"),
("119","Statistic","mod_statistic","right","3","99","0","23,18,41,3,2,8,42","today=1;\nyesterday=1;\nthisweek=1;\nlastweek=1;\nthismonth=1;\nlastmonth=1;\nall=0;\ninfo=0;\n","","","1"),
("96","Next","mod_article_nextprev","article-mid","0","99","1","23,18,41,36,49,93,3,2,8,42,40,43,48,96,97,98","cat=1,2,3,55;\nfilter=;\n","","","0"),
("120","User Panel","mod_user","right","0","99","0","23,18,41,3,2,8,42","","","","1"),
("122","DJ Equipment Rental","mod_article_nextprev","top2","0","99","1","23,110,18,103,41,105,3,2,8,42,107,108","cat=;\nfilter=;\n","","","1");

--

DROP TABLE IF EXISTS `db_prefix_permalink`;

--

CREATE TABLE `db_prefix_permalink` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `link` text NOT NULL,
  `permalink` varchar(250) NOT NULL,
  `pid` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `locker` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permalink` (`permalink`)
) ENGINE=MyISAM AUTO_INCREMENT=304 DEFAULT CHARSET=latin1;

--

INSERT INTO `db_prefix_permalink` (`id`,`link`,`permalink`,`pid`,`status`,`locker`) VALUES ("232","?app=article&view=archives&feed=rss","archives.rss","41","1","0"),
("231","?app=article&view=item&id=17","blog/fiyo-cms-1-5-5.html","3","1","0"),
("230","?app=article&view=category&id=1","blog","3","1","0"),
("233","?app=article&view=item&id=14","blog/fiyo-cms-1-5-0.html","3","1","0"),
("234","?app=article&view=item&id=6","blog/fiyo-1-2-2-dengan-fitur-lebih-canggih.html","3","1","0"),
("235","?app=article&view=item&id=175","blog/fiyo-cms-1-4-0.html","3","1","0"),
("240","?app=user","user","3","1","0"),
("238","?app=user&view=logout","user/logout","3","1","0"),
("241","?app=user&view=edit","user/edit","3","1","0"),
("242","?app=user&view=login","user/login","3","1","0"),
("243","?app=user&view=register","user/register","3","1","0"),
("244","?app=user&view=lost_password","user/remember","3","1","0"),
("245","?app=search","search","3","1","0"),
("246","?app=contact&view=group&id=1","contact/developer","8","1","0"),
("247","?app=article&view=item&id=12","blog/mengenal-lebih-dekat-tentang-fiyo-cms.html","3","1","0"),
("248","?app=contact&view=person&id=1","contact/developer/first-ryan.html","3","1","0"),
("249","?app=article&tag=Home","tag/home","3","1","0"),
("250","?app=article&tag=CMS","tag/cms","3","1","0"),
("251","?app=article&view=item&id=182","news/fiyo-cms-1-5-7-3-0.html","3","1","0"),
("252","?app=article&view=category&id=2","news","3","1","0"),
("253","?app=article&view=item&id=10","news/fiyo-cms-1-3-0.html","3","1","0"),
("254","?app=article&view=item&id=7","blog/update-checkpoint-di-versi-1-2-3.html","3","1","0"),
("255","?app=article&tag=Review","tag/review","3","1","0"),
("256","?app=article&tag=Review&feed=rss","tag/review.rss","3","1","0"),
("257","?app=article&tag=Teknologi","tag/teknologi","3","1","0"),
("258","?app=article&tag=Teknologi&feed=rss","tag/teknologi.rss","3","1","0"),
("259","?app=article&view=category&id=2&feed=rss","news.rss","3","1","0"),
("260","?app=article&tag=CMS&feed=rss","tag/cms.rss","3","1","0"),
("261","?app=article&view=category&id=1&feed=rss","blog.rss","3","1","0"),
("262","?app=article&view=item&id=183","blog/apa-saja-yang-baru-di-fiyo-2-0.html","3","1","0"),
("263","?app=contact","contact","8","1","0"),
("264","?app=article&amp;view=item&amp;id=182","news/fiyo-cms-1-5-7-3-0-2.html","23","1","0"),
("265","?app=article&amp;view=item&amp;id=175","blog/fiyo-cms-1-4-0-2.html","3","1","0"),
("266","?app=article&amp;view=item&amp;id=10","news/fiyo-cms-1-3-0-2.html","23","1","0"),
("267","?app=article&amp;view=item&amp;id=183","blog/apa-saja-yang-baru-di-fiyo-2-0-2.html","3","1","0"),
("268","?app=article&amp;view=item&amp;id=17","blog/fiyo-cms-1-5-5-2.html","3","1","0"),
("269","?app=article&amp;view=item&amp;id=14","blog/fiyo-cms-1-5-0-2.html","3","1","0"),
("270","?app=article&amp;view=item&amp;id=7","blog/update-checkpoint-di-versi-1-2-3-2.html","3","1","0"),
("271","?app=article&amp;view=item&amp;id=12","blog/mengenal-lebih-dekat-tentang-fiyo-cms-2.html","3","1","0"),
("272","?app=article&amp;view=item&amp;id=6","blog/fiyo-1-2-2-dengan-fitur-lebih-canggih-2.html","3","1","0"),
("273","?app=article&view=item&id=4","blog/fitur-baru-di-v-1-2-0.html","3","1","0"),
("274","?app=article&amp;view=item&amp;id=4","blog/fitur-baru-di-v-1-2-0-2.html","3","1","0"),
("275","?app=article&view=item&id=1","blog/fiyo-cms-hadir-pada-tahun-2012.html","3","1","0"),
("276","?app=article&view=item&id=8","blog/membuat-template-fiyocms.html","3","1","0"),
("277","?app=article&amp;view=item&amp;id=1","blog/fiyo-cms-hadir-pada-tahun-2012-2.html","3","1","0"),
("278","?app=article&amp;view=item&amp;id=8","blog/membuat-template-fiyocms-2.html","3","1","0"),
("279","?app=gallery&view=default","gallery","110","1","0"),
("290","?app=gallery&view=item&id=7","gallery/administrator/tetteet.html","110","1","0"),
("289","?app=gallery&view=item&id=5","gallery/administrator/aaaa.html","110","1","0"),
("288","?app=gallery&view=category&id=1","gallery/administrator","110","1","0"),
("291","?app=gallery&view=category&id=2","gallery/a","110","1","0"),
("292","?app=gallery&view=category&id=3","gallery/test","110","1","0"),
("293","?app=gallery&view=category&id=4","gallery/aaasd","110","1","0"),
("294","?app=gallery&view=item&id=9","gallery/admin-panel-galelry/admin-panel-biru-kota-megah.html","110","1","0"),
("295","?app=gallery&view=category&id=5","gallery/asdsd","110","1","0"),
("296","?app=gallery&view=item&id=10","gallery/admin-panel-galelry/admin-panel-batik.html","110","1","0"),
("297","?app=gallery&view=item&id=11","gallery/admin-panel-galelry/admin-panel-warna-warni.html","110","1","0"),
("298","?app=gallery&view=item&id=12","gallery/admin-panel-galelry/modul-kontrol-temperatur-air-berbasis-pid-menggunakan-matlab-simulink.html","110","1","0"),
("299","?app=gallery&view=category&id=12","gallery/administrator-2.html","110","1","0"),
("300","?app=gallery&view=item&id=16","gallery/administrator/dj-equipment-rental.html","110","1","0"),
("301","?app=gallery&view=item&id=17","gallery/administrator/dj-equipment-rental-2.html","110","1","0"),
("302","?app=gallery&view=item&id=18","gallery/administrator/lumidians.html","110","1","0"),
("303","?app=article&view=item&id=195","blog/program-studi.html","3","1","0");

--

DROP TABLE IF EXISTS `db_prefix_plugin`;

--

CREATE TABLE `db_prefix_plugin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `folder` varchar(20) NOT NULL,
  `status` smallint(1) NOT NULL,
  `parameter` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `folder_2` (`folder`),
  KEY `folder` (`folder`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--

INSERT INTO `db_prefix_plugin` (`id`,`folder`,`status`,`parameter`) VALUES ("1","plg_sef","1",""),
("2","plg_cache","1",""),
("3","plg_recaptcha","1",""),
("4","plg_statistic","1","");

--

DROP TABLE IF EXISTS `db_prefix_session_login`;

--

CREATE TABLE `db_prefix_session_login` (
  `user_id` int(11) NOT NULL,
  `session_id` varchar(100) NOT NULL,
  `level` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--

INSERT INTO `db_prefix_session_login` (`user_id`,`session_id`,`level`,`time`) VALUES ("6","demo","3","2014-09-22 11:47:04"),
("5","admin","1","2014-10-11 12:49:47");

--

DROP TABLE IF EXISTS `db_prefix_setting`;

--

CREATE TABLE `db_prefix_setting` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

--

INSERT INTO `db_prefix_setting` (`id`,`name`,`value`) VALUES ("1","site_theme","curve"),
("2","admin_theme","fiyo"),
("3","site_name","Admin"),
("4","site_keys","keyword 1, keyword two, 3rd key"),
("5","site_desc","admin"),
("6","site_title","Fast, Save & Elegant!"),
("7","site_url","localhost"),
("8","site_status","1"),
("9","sef_url","1"),
("10","file_allowed","swf flv avi mpg mpeg qt mov wmv asf rm rar zip exe msi iso"),
("11","file_size","5120"),
("12","media_theme","oxygen"),
("13","title_type","1"),
("14","title_divider"," - "),
("15","sef_www","1"),
("16","sef_ext",".html"),
("17","site_mail","your@site.net"),
("18","backend_folder","dapur"),
("19","follow_link","1"),
("20","member_registration","1"),
("21","member_activation","2"),
("22","member_group","3"),
("23","version","2.0 1.2"),
("24","lang","id"),
("25","timezone","Asia/Jakarta"),
("26","api_key","500"),
("27","disk_space","5000");

--

DROP TABLE IF EXISTS `db_prefix_statistic`;

--

CREATE TABLE `db_prefix_statistic` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ip` varchar(20) NOT NULL,
  `user_id` int(10) NOT NULL,
  `time` datetime NOT NULL,
  `browser` varchar(30) NOT NULL,
  `platform` varchar(30) NOT NULL,
  `country` varchar(15) NOT NULL,
  `city` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;

--

INSERT INTO `db_prefix_statistic` (`id`,`ip`,`user_id`,`time`,`browser`,`platform`,`country`,`city`) VALUES ("1","127.0.0.1","1","2014-09-12 23:45:41","Chrome","Windows","Local","Local"),
("2","127.0.0.1","1","2014-09-13 00:04:46","Chrome","Windows","Local","Local"),
("3","127.0.0.1","0","2014-09-13 11:40:06","Chrome","Windows","Local","Local"),
("4","127.0.0.1","1","2014-09-16 13:06:47","Chrome","Windows","Local","Local"),
("5","127.0.0.1","1","2014-09-16 17:11:48","Chrome","Windows","Local","Local"),
("6","127.0.0.1","1","2014-09-17 00:34:00","Chrome","Windows","Local","Local"),
("7","127.0.0.1","0","2014-09-17 12:05:40","Chrome","Windows","Local","Local"),
("8","127.0.0.1","1","2014-09-17 14:31:55","Chrome","Windows","Local","Local"),
("9","127.0.0.1","1","2014-09-17 16:33:21","Chrome","Windows","Local","Local"),
("10","127.0.0.1","1","2014-09-17 22:47:43","Chrome","Windows","Local","Local"),
("11","127.0.0.1","1","2014-09-18 00:42:03","Chrome","Windows","Local","Local"),
("12","127.0.0.1","1","2014-09-18 11:38:45","Chrome","Windows","Local","Local"),
("13","127.0.0.1","0","2014-09-18 12:16:02","Msie","Windows","Local","Local"),
("14","127.0.0.1","0","2014-09-18 13:47:11","Chrome","Windows","Local","Local"),
("15","127.0.0.1","1","2014-09-18 23:11:24","Chrome","Windows","Local","Local"),
("16","127.0.0.1","1","2014-09-19 01:38:06","Chrome","Windows","Local","Local"),
("17","127.0.0.1","1","2014-09-19 23:32:33","Chrome","Windows","Local","Local"),
("18","127.0.0.1","1","2014-09-20 01:26:11","Chrome","Windows","Local","Local"),
("19","127.0.0.1","1","2014-09-20 11:45:57","Chrome","Windows","Local","Local"),
("20","127.0.0.1","0","2014-09-20 11:55:39","Msie","Windows","Local","Local"),
("21","127.0.0.1","1","2014-09-20 12:34:21","Chrome","Windows","Local","Local"),
("22","127.0.0.1","1","2014-09-20 15:50:58","Chrome","Windows","Local","Local"),
("23","127.0.0.1","1","2014-09-20 23:46:55","Chrome","Windows","Local","Local"),
("24","127.0.0.1","1","2014-09-21 00:57:25","Chrome","Windows","Local","Local"),
("25","127.0.0.1","1","2014-09-21 11:45:52","Chrome","Windows","Local","Local"),
("26","127.0.0.1","1","2014-09-21 15:22:21","Chrome","Windows","Local","Local"),
("27","127.0.0.1","1","2014-09-21 17:30:13","Chrome","Windows","Local","Local"),
("28","127.0.0.1","1","2014-09-22 00:09:11","Chrome","Windows","Local","Local"),
("29","127.0.0.1","2","2014-09-22 11:30:09","Chrome","Windows","Local","Local"),
("30","127.0.0.1","5","2014-09-23 00:15:08","Chrome","Windows","Local","Local"),
("31","127.0.0.1","5","2014-09-23 12:16:33","Chrome","Windows","Local","Local"),
("32","127.0.0.1","0","2014-09-26 22:08:57","Chrome","Windows","Local","Local"),
("33","127.0.0.1","0","2014-09-30 02:06:56","Chrome","Windows","Local","Local"),
("34","127.0.0.1","0","2014-09-30 02:10:56","Chrome","Windows","Local","Local"),
("35","127.0.0.1","5","2014-09-30 09:14:49","Chrome","Windows","Local","Local"),
("36","127.0.0.1","5","2014-09-30 11:14:51","Chrome","Windows","Local","Local"),
("37","127.0.0.1","5","2014-09-30 13:15:17","Chrome","Windows","Local","Local"),
("38","127.0.0.1","0","2014-09-30 23:48:11","Chrome","Windows","Local","Local"),
("39","127.0.0.1","5","2014-10-01 01:09:18","Chrome","Windows","Local","Local"),
("40","127.0.0.1","5","2014-10-01 03:59:13","Chrome","Windows","Local","Local"),
("41","127.0.0.1","0","2014-10-02 13:51:22","Chrome","Windows","Local","Local"),
("42","127.0.0.1","0","2014-10-03 00:21:23","Chrome","Windows","Local","Local"),
("43","127.0.0.1","0","2014-10-06 23:12:13","Chrome","Windows","Local","Local"),
("44","127.0.0.1","0","2014-10-10 00:08:36","Chrome","Windows","Local","Local"),
("45","127.0.0.1","5","2014-10-10 04:46:16","Chrome","Windows","Local","Local"),
("46","127.0.0.1","5","2014-10-10 22:08:39","Chrome","Windows","Local","Local"),
("47","127.0.0.1","5","2014-10-11 00:00:22","Chrome","Windows","Local","Local"),
("48","127.0.0.1","5","2014-10-11 09:15:32","Chrome","Windows","Local","Local"),
("49","127.0.0.1","0","2014-10-11 10:26:16","Firefox","Windows","Local","Local"),
("50","127.0.0.1","5","2014-10-11 11:21:24","Chrome","Windows","Local","Local");

--

DROP TABLE IF EXISTS `db_prefix_statistic_online`;

--

CREATE TABLE `db_prefix_statistic_online` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(20) NOT NULL,
  `url` tinytext NOT NULL,
  `time` int(11) NOT NULL,
  `browser` varchar(20) NOT NULL,
  `platform` varchar(20) NOT NULL,
  `country` varchar(30) NOT NULL,
  `city` varchar(50) NOT NULL,
  `key` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=236 DEFAULT CHARSET=latin1;

--

INSERT INTO `db_prefix_statistic_online` (`id`,`ip`,`url`,`time`,`browser`,`platform`,`country`,`city`,`key`) VALUES ("235","127.0.0.1","http://localhost/fiyo_2/","1413008061","Chrome","Windows","Local","Local","aa5513da1ab5ac67ae6b52c0ad7a25b4");

--

DROP TABLE IF EXISTS `db_prefix_user`;

--

CREATE TABLE `db_prefix_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` int(2) NOT NULL,
  `level` int(11) NOT NULL DEFAULT '3',
  `time_reg` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `time_log` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `about` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user` (`user`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--

INSERT INTO `db_prefix_user` (`id`,`user`,`name`,`password`,`email`,`status`,`level`,`time_reg`,`time_log`,`about`) VALUES ("5","admin","Administrator","21232f297a57a5a743894a0e4a801fc3","admin@admin.com","1","1","2014-09-22 11:34:00","2014-10-11 12:49:47",""),
("2","admin2","Administrator","21232f297a57a5a743894a0e4a801fc3","admin@admin2.com","1","1","2014-09-22 11:03:03","2014-09-22 11:03:09",""),
("6","demo","Developer","fe01ce2a7fbac8fafaed7c982a04e229","demo@gmail.com","1","3","2014-09-22 11:46:53","2014-09-22 11:47:04","");

--

DROP TABLE IF EXISTS `db_prefix_user_group`;

--

CREATE TABLE `db_prefix_user_group` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(50) NOT NULL,
  `level` int(2) NOT NULL,
  `description` text NOT NULL,
  `allowed_apps` varchar(200) NOT NULL,
  `default_apps` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `level` (`level`),
  KEY `group` (`group_name`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

--

INSERT INTO `db_prefix_user_group` (`id`,`group_name`,`level`,`description`,`allowed_apps`,`default_apps`) VALUES ("1","Super Administrator","1","Super Administrator","",""),
("2","Administrator","2","Admin","",""),
("10","asdasd","3","","",""),
("33","Member","4","aaewe","","");

--

